function stim = getRandomBarSequence( stim )
% stim = getBarSequence( stim );
%
% DESCRIPTION
% Computes center and direction of motion of the bar stimulus. 
% Start by creating 4 sweeps with bar orient: 0, 45, 90, 135 deg, separated by stim.durBlanksSec blank period
% Then Shuffle bar positions (leaving blank periods intact)
% INPUT
%   stim
%       .numTRs     - duration of sequence in TRs
%       .degPerSec  - a min and max speed in deg/sec
%   	.radDeg     - radius of apperture in degrees
%   	.widthDeg   - width of bar in degrees
%   	.durBlanksSec   - duration of blanks
%
% OUTPUT
%   stim
%       .centersDeg - centers in deg, (0,0) is screen center (-y is up)
%   	.motDirsRad     - direction of motion in radians (0 to the right, pi/2 is up)
%   	.degPerSec  - instantaneous speed at every TR

% VERSION HISTORY
%   2013.03.07 PB


myOrient = [0 1/4 2/4 3/4]*pi; % bar orientations
nsteps = stim.nSteps; %(stim.radDeg*2) / degPerSec; % steps in each orientation
blankdur = stim.durBlanksSec/stim.secPerTR;
% degPerSec = stim.degPerSecRange(1);
degPerSec = ((stim.radDeg*2 - 0.5*stim.widthDeg) / nsteps) / stim.secPerTR;

ct = 0;
mymat = NaN(nsteps*length(myOrient),3);
for iOr = 1:length(myOrient)
    theta = myOrient(iOr);
    curCenter = -( stim.radDeg - 0.5*stim.widthDeg ) * [cos(theta), -sin(theta)]; % starting position (at the edge of the stim aperture)
    dx = cos(theta) * degPerSec * stim.secPerTR;
    dy = -sin(theta) * degPerSec * stim.secPerTR;
    
    for iS = 1:nsteps
        ct = ct+1;
        % save curr position
        mymat(ct,:) = [theta curCenter];
        % update variables
        curCenter = curCenter + [dx,dy];
    end
end

mymat = repmat(mymat,2,1);

% randomize positions
if isfield( stim, 'seed' )
    % set seed to generate standard sequence
    rand('seed',stim.seed);
end
ind = randperm(size(mymat,1));
% ind = 1:size(mymat,1);

% add blanks
stimdur = floor(length(ind)/length(myOrient));
myidices = [];
for ib = 1:length(myOrient)
    moveby = stimdur*(ib-1);
    tmp = ind( (1 : stimdur)+moveby );
    tmp = [tmp NaN(1,blankdur)];
    myidices = cat(2,myidices,tmp);
end

% save into stim struct
stim.numTRs = length(myidices);

stim.centersDeg = zeros(stim.numTRs,2);
stim.motDirsRad = zeros(stim.numTRs,1);
stim.degPerSec = zeros(stim.numTRs,1);

for iTR = 1:stim.numTRs
    
    thisind = myidices(iTR);
    if ~isnan(thisind)
        stim.motDirsRad(iTR) = mymat(thisind,1);
        stim.centersDeg(iTR,:) = [mymat(thisind,2) mymat(thisind,3)] ;
        stim.degPerSec(iTR) = degPerSec;
    else
        stim.centersDeg(iTR,:) = [stim.radDeg stim.radDeg]*2 ;
        stim.motDirsRad(iTR) = 0;
        stim.degPerSec(iTR) = degPerSec;
    end
end








%%
% Or = NaN(nsteps,length(myOrient));
% Cx = Or; Cy = Or;
% for iOr = 1:length(myOrient)
%     
%     theta = myOrient(iOr);
%     curCenter = -( stim.radDeg - 0.5*stim.widthDeg ) * [cos(theta), -sin(theta)]; % starting position (at the edge of the stim aperture)
%     dx = cos(theta) * degPerSec * stim.secPerTR;
%     dy = -sin(theta) * degPerSec * stim.secPerTR;
%     
%     for iS = 1:nsteps
%         Or(iS,iOr) = theta;
%         Cx(iS,iOr) = curCenter(1);
%         Cy(iS,iOr) = curCenter(2);
%         
%         
%         curCenter = curCenter + [dx,dy];
%     end
% end
% 
% Or = Or(:);
% Cx = Cx(:);
% Cy = Cy(:);
% 
% if isfield( stim, 'seed' )
%     % set seed to generate standard sequence
%     rand('seed',stim.seed); 
% end
% ind = randperm(length(Or));
% ind = 1:length(Or);
% 
% blankdur = stim.durBlanksSec/stim.secPerTR;
% stimdur = floor(length(ind)/length(myOrient));
% 
% 
% myidices = [];
% for ib = 1:length(myOrient)
%     moveby = stimdur*(ib-1);
%     tmp = ind( (1 : stimdur)+moveby );
%     tmp = [tmp NaN(1,blankdur)];
%     myidices = cat(2,myidices,tmp);
% end
% 
% 
% stim.numTRs = length(myidices);
% 
% stim.centersDeg = zeros(stim.numTRs,2);
% stim.motDirsRad = zeros(stim.numTRs,1);
% stim.degPerSec = zeros(stim.numTRs,1);
% 
% for iTR = 1:stim.numTRs
%     
%     thisind = myidices(iTR);
%     if ~isnan(thisind)
%         stim.centersDeg(iTR,:) = [Cx(thisind) Cy(thisind)] ;
%         stim.motDirsRad(iTR) = Or(thisind);
%         stim.degPerSec(iTR) = degPerSec;
%     else
%         stim.centersDeg(iTR,:) = [stim.radDeg stim.radDeg]*2 ;
%         stim.motDirsRad(iTR) = 0;
%         stim.degPerSec(iTR) = degPerSec;
%     end
% end


