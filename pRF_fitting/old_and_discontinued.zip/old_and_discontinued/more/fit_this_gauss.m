function [err, ypred] = fit_this_gauss(RF,x,y,yobs,errtype)

mygauss = exp( -( (x-RF.center(1)).^2 + (y-RF.center(2)).^2 ) / (2*RF.sig(1)^2) );
% mygauss = mygauss / sum(mygauss(:)) * 10;
ypred = RF.offset + RF.amp * mygauss(:);


err = NaN;
if exist('yobs','var')
    if ~isempty(yobs)
        
        if strcmp(errtype,'corr')
            
            tmp = corrcoef(yobs,ypred);
            err = -tmp(2);
            
        else
            
            err = mean( (yobs-ypred).^2 );
            
        end
        
    end
end
    