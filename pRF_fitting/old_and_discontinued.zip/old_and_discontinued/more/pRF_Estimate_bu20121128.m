function [pRFs HDR opt pRFs_ihdr misc] = pRF_Estimate(vtc,stim,s,lrs,opt)
%
%
% modified from Geoff and Ione's prf fitting & prf/hdr iterative fitting codes
%
% 2012/07 - removed iterative hdr fitting and added option for mse and DoG. PB
% 2012/08 - changed resolution of initialization mat to 0.5deg
%
% inputs:
%
% vtc -> fMRI data
%     vtc(1:nvoxels).tc (1D vector, rows=TRs)
%     vtc(1:nvoxels).id (Voxel indices, useful for vmp creation)
%
% stim ->
%       .secPerTR   - TR duration in seconds
%       .numTRs     - stim.durSec / stim.secPerTr
%
% s and lrs -> stimulus movie at 2 resolutions (coarser is used only to
%       initialize the fit) with the following fields:
%     s.frames (the stimulus) [4D: x,y,timeinarun,differentruns]
%     s.x and s.y (meshgrid)
%     s.nx and s.ny (length of x and y)
% 	  s.dx and s.dy (steps in degrees)
%
% opt -> optional inputs
%     [opt.gof ('corr','mse') measure of goodness of fit ] default is 'corr'
%     [opt.prfmodel ('Gauss','DoG') pRF model] default is 'Gauss'
%     [opt.corrthr (if max(corr(resp,seedsMat))>thr, do nonlinear
%             fitting, else put NaN)] default is 0.25
%     [opt.findscaling (1/0) use polyval to find amplitude and offset
%             that, given each pRF, best explain the fMRI timecourse. not free
%             parameters.] default is 1
%     [opt.parallel (1/0) use parallelization toolbox] default is 0
%     [opt.constrainfit2maxEccDeg  (deg)   - force fit to avoid sig values smaller than
%               the stimulus matrix resolution and eccentricity values
%               larger than maximum tested eccentricity] default is Inf
%     [opt.estimatehdr -> DISABLED. always set to 0]
%     [opt.hdr (.tau and .delay params to fit pRFs, or initialize the iterative hdr fitting)] default is Boynton '96
%     [opt.vtcsize (4D size of original BV vtc, useful for vmp creation)] default is []
%
%
%
% outputs:
%
% pRFs -> 3 kinds of variables: fitted (center and sig + tau and delay if opt.estimatehdr),
%         estimated after fitting the prf (co, amp and offset) and copies of preset values (id)
%     pRFs(1:nvoxels).center : x,y position
%     pRFs(1:nvoxels).sig : sigma (of the pos,neg lobe if pRF model is DoG; only pos lobe if model is Gauss)
%     pRFs(1:nvoxels).co : correlation
% 	  pRFs(1:nvoxels).amp : scaling factor (not a free param)
%     pRFs(1:nvoxels).offset : offset (not a free param and not a property of the pRF .. just dc of fMRI timecourse)
%     pRFs(1:nvoxels).id : voxel id (copied from vtc(:).id)
%
% HDR -> estimated (if opt.estimatehdr) or Boynton '96
%     HDR.tau
%     HDR.delay
%     HDR.n
%     HDR.dt
%     HDR.th
%     HDR.function
%
% opt -> as in input, but updated with defaults
%
% pRFs_ihdr -> if opt.estimatehdr, a subset of voxels is selected,
%       where pRF and HDR are simultaneously estimated (iterative procedure).
%       The median of fitted tau and delay parameters is then used to
%       recompute the hdr for the final pRFs fitting. Fields of the pRFs_ihdr structure
%       are (non NaNs only for the selected subset of voxels and if opt.estimatehdr):
%       .center, .sig, -> parameters of the iteratively fitted pRF
%       .tau, .delay, -> parameters of the iteratively fitted hdr
%       .co -> correlation of the fit of pRF and hdr
%       .id
%
% misc ->
%     misc.pRFestimation_time (in s)
%     misc.hdrestimation_time (in s) -> NaN if ~opt.estimatehdr
%
%
% functions required:
% UW_toolbox/Optimization (fit interface)
% Gamma.m (Geoff's) -> rename the function capitalizing the initial to
%                                           avoid conflict with Matlab built-in function
% fitPRF_corr.m
% fitPRF_mse.m
% Gauss.m
% mycorr.m (Paola's correlation)
%
%
%
% Paola, 2012/02/18


%% set defaults
opt.estimatehdr = 0; 
if ~isfield(opt,'corrthr'), opt.corrthr = 0.25; end
if ~isfield(opt,'parallel'), opt.parallel = 0; end
if ~isfield(opt,'findscaling'), opt.findscaling = 1; end
if ~isfield(opt,'constrainfit2maxEccDeg'), opt.constrainfit2maxEccDeg = Inf; end
if ~isfield(opt,'vtcsize'), opt.vtcsize = []; end
if ~isfield(opt,'gof'), opt.gof = 'corr'; end
if ~isfield(opt,'prfmodel'), opt.prfmodel = 'Gauss'; end
if isfield(opt,'hdr')
    HDR = opt.hdr;
else %  Boynton et al. '96
    HDR.tau = 1.5; %seconds
    HDR.delay = 2.25;  %seconds
end
opt_gofcorr = opt; opt_gofcorr.gof = 'corr';
opt_gofmse = opt; opt_gofmse.gof = 'mse';

if strcmp(opt.gof,'mse')
    opt.findscaling = 0;
end
if strcmp(opt.prfmodel,'Gauss')
    indfrelist = '(1)';
elseif strcmp(opt.prfmodel,'DoG')
    indfrelist = '(1:2)';
else
    error('prfmodel unknown')
end

HDR.n = 3;
HDR.dt = stim.secPerTR;
HDR.th = 0:HDR.dt:30;
HDR.function = shiftdim(Gamma(HDR.n,HDR.tau,HDR.th-HDR.delay),-1);  %use shiftdim to make it a 1x1xn vector

%% Create stimulus timecourses convolved by HDR
% if opt.estimatehdr , will be overwritten
disp('creating predicted timecourses ...')
tic

% loop through the n different Runs (saved as 4th dimension of s.frames),
% convolve stimuli timecourses with hdr, collapse the 2 spatial dimensions
% into one AND ONLY THEN
% concatenate subsequent runs -> to avoid predicting a response at the 1st
% TR of the 5th run (for example) due to a stimulus presented on the last
% TR of the 4th run.

UnwrappedConvStim = [];
for nR = 1:size(s.frames,4)
    % convolve the time-course of each pixel in the stimulus with the HDR.
    ConvStim = stim.secPerTR*convn(s.frames(:,:,:,nR),HDR.function); ConvStim = ConvStim(:,:,1:stim.numTRs);  %truncate the extra padding after the convolution
    % unwrap the 3D matrix (x,y,time) into a 2D matrix (time,space)
    UnwrappedConvStim = cat( 1,UnwrappedConvStim,    s.dx*s.dy*reshape(ConvStim,[s.nx*s.ny,stim.numTRs])'     ); clear ConvStim
end

%% Seeds for fit initialization
%
% define a series of potential pRFs that are used as starting
% points for the nonlinear optimization process. Here,
% one every 0.5 deg x 1:2:10 sigma 
step = 0.5; 
seedX = min(lrs.x(:)) : step : max(lrs.x(:));
seedY = min(lrs.y(:)) : step : max(lrs.y(:));

% seedX = lrs.x(1,1:2:end);
% seedY = lrs.y(1:2:end,1);
seedSig = linspace(1,10,5); %
% create all possible combinations
[xList,yList,sigList] = ndgrid(seedX,seedY,seedSig);
% unwrap into 1D vectors length(seedX)*length(seedY)*length(seedSig) long
xList = xList(:);
yList = yList(:);
sigList = sigList(:);

% columns of matSeeds will hold the unwrapped Gaussian pRFs
% matrix size: [lrs.nx*lrs.ny , length(seedX)*length(seedY)*length(seedSig)]
% this is where OUT OF MEMORY is likely to occur. decrease lrs.nx and ny to fix
SeedsPredResp = zeros(size(UnwrappedConvStim,1),length(xList));

for i = 1:length(xList)
    seedRF(i).center = [xList(i),yList(i)];
    
    if strcmp(opt.prfmodel,'DoG')
        seedRF(i).sig = [sigList(i) 2*sigList(i)];
        seedRF(i).amp = [1 .5];
    else
        seedRF(i).sig = [sigList(i) NaN];
        seedRF(i).amp = [1 NaN];
    end
    seedRF(i).offset = 0;
    seedRF(i).shutup = 1;
    seedRF(i).co = NaN;
    seedRF(i).id = NaN;
    
    
    RF = seedRF(i);
    
    PredResp = 0;
    for ind = 1:1+strcmp(opt.prfmodel,'DoG')
        PredResp = PredResp + sign((ind<2)-.5) * RF.amp(ind) * UnwrappedConvStim*Gauss(RF,s.x,s.y,ind,1);
    end
    
    % each column is the time course predicted by one seedRF
    SeedsPredResp(:,i) = PredResp;
    
    if ~mod(i,100), fprintf('..%i..',i); end
end



%% initialize pRF structures
% takes no time and reduces clutter in the parfor loop
parfor voxNum = 1:length(vtc)
    
    % pRFs
    pRFs(voxNum).center = [NaN NaN]; % x,y
    pRFs(voxNum).sig = [NaN NaN]; % pos and neg lobe (if pRF model is DoG)
    pRFs(voxNum).co = NaN;
    pRFs(voxNum).err = NaN;
    pRFs(voxNum).amp = [NaN NaN];
    pRFs(voxNum).offset = NaN;
    pRFs(voxNum).id = NaN;
    
end
misc.hdrestimation_time = NaN;
toc

%% estimate iHDR -> removed 2012.06.05
pRFs_ihdr = [];

%% estimate pRFs
% initialize progress monitor bar -> dwnld free pkg "ParforProgMon"
if opt.parallel, ppm = ParforProgMon([ 'pRF fitting started at '  datestr(now,'HH:MM')], length(vtc) ); else ppm.increment = NaN; end
tic
disp('start pRFestimate, looping through voxels ...')

if strcmp(opt.gof,'corr')
    parfor voxNum = 1:length(vtc)
        
        % initializations required by parfor
        vN = voxNum;
        ObsResp = vtc(vN).tc;
        
        % show current status
        if ~opt.parallel, fprintf('voxNum %d of %d \n',vN,size(vtc,2)); end
        ppm.increment();
        
        % save voxel .id in pRF struct
        pRFs(voxNum).id = vtc(vN).id;
        
        % find best seed to initialize pRF fitting
        basiscorr = mycorr(ObsResp,SeedsPredResp);
        [maxcorr bestseed] = max(basiscorr);
        
        if maxcorr < opt.corrthr
            pRFs(voxNum).co = maxcorr;
            
        else
            disp(sprintf('..%i..',vN))
            
            [tmpRF err] = fit('fitPRF_corr',seedRF(bestseed),{'center','sig'},UnwrappedConvStim,ObsResp,s,opt);
            pRFs(voxNum).co = -err;
            
            
            pRFs(voxNum).center = tmpRF.center;
            pRFs(voxNum).sig = tmpRF.sig;
            
            if opt.findscaling
                % find scaling and offset that best explain the ObsResp given the
                % fitted pRF (only if opt.gof = 'corr')
                if strcmp(opt.prfmodel,'Gauss')
                    PredResp = UnwrappedConvStim*Gauss(tmpRF,s.x,s.y,1,1);
                    polyVals = polyfit(PredResp,ObsResp,1);
                    tmpRF.amp = [polyVals(1) NaN];
                    tmpRF.offset = polyVals(2);
                elseif strcmp(opt.prfmodel,'DoG')
                    [tmpRF err] = fit('fitPRF_mse',tmpRF,{['amp' indfrelist],'offset'},UnwrappedConvStim,ObsResp,s,opt);
                end
                % estimate error
                [tmpRF err] = fit('fitPRF_mse',tmpRF,{},UnwrappedConvStim,ObsResp,s,opt);
                pRFs(voxNum).err = err;
                
                pRFs(voxNum).amp = tmpRF.amp;
                pRFs(voxNum).offset = tmpRF.offset;
            end
            
        end
    end
elseif strcmp(opt.gof,'mse') % mse fitting
    parfor voxNum = 1:length(vtc)
        
        % initializations required by parfor
        vN = voxNum;
        ObsResp = vtc(vN).tc;
        
        % show current status
        if ~opt.parallel, fprintf('voxNum %d of %d \n',vN,size(vtc,2)); end
        ppm.increment();
        
        % save voxel .id in pRF struct
        pRFs(voxNum).id = vtc(vN).id;
        
        % find best seed to initialize pRF fitting
        basiscorr = mycorr(ObsResp,SeedsPredResp);
        [maxcorr bestseed] = max(basiscorr);
        
        if maxcorr < opt.corrthr
            pRFs(voxNum).co = maxcorr;
            
        else
            disp(sprintf('..%i..',vN))
            
            % estimate amplitude and offset paramters given the best 'seed pRF'
            tmpRF = seedRF(bestseed);
            if strcmp(opt.prfmodel,'Gauss')
                PredResp = UnwrappedConvStim*Gauss(tmpRF,s.x,s.y,1,1);
                polyVals = polyfit(PredResp,ObsResp,1);
                tmpRF.amp = [polyVals(1) NaN];
                tmpRF.offset = polyVals(2);
            elseif strcmp(opt.prfmodel,'DoG')
                tmpRF = fit('fitPRF_mse',tmpRF,{['amp' indfrelist],'offset'},UnwrappedConvStim,ObsResp,s,opt);
            end
            
            % fit of all parameters
            [tmpRF err] = fit('fitPRF_mse',tmpRF,{'center',['sig' indfrelist],['amp' indfrelist],'offset'},UnwrappedConvStim,ObsResp,s,opt);
%             [tmpRF err] = fit('fitPRF_mse',tmpRF,{'center',['sig' indfrelist]},UnwrappedConvStim,ObsResp,s,opt);
            pRFs(voxNum).err = err;
            
            % estimate correlation as well
            [tmpRF err] = fit('fitPRF_corr',tmpRF,{},UnwrappedConvStim,ObsResp,s,opt_gofcorr);
            pRFs(voxNum).co = -err;
            
            pRFs(voxNum).center = tmpRF.center;
            pRFs(voxNum).sig = tmpRF.sig;
            pRFs(voxNum).amp = tmpRF.amp;
            pRFs(voxNum).offset = tmpRF.offset;
            
        end
    end
else
    error('unkonwn opt.gof (goodness of fit index) parameter')
end
misc.pRFestimation_time = toc;

disp(sprintf('\n prf estimation completed in %i min \n', round(misc.pRFestimation_time/60)))
fprintf('\n\n\n')


