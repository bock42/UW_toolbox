function err = fitPRF_corr(RF,UnwrappedConvStim,ObsResp,s,opt)
%
%  err = fitPRF(RF,UnwrappedConvStim,ObsResp,s,opt)
% 
% input:
%
% RF -> RF.center, RF.sig
% ObsResp -> fMRI timecourse
% s -> stimulus movie 
%        s.frames [x,y,time]
%        s.x, x.y
% opt -> options for fitting 
%         opt.constrainfit - (1/0) force fit to avoid sig values smaller than the stimulus matrix resolution and 
%             eccentricity values larger than  (stimulus display + 2 deg)
% 
% output:
% 
% err = -correlation between predicted and observed fMRI timecourse
%
% modified by Paola on 2012/02/10 to include cost functions 

% stimulus([space,time]) * thisprf([time,1]) = predictedfMRItimecourse([time,1])
correl = 0;
for runNum = 1:size(UnwrappedConvStim,3)
    PredResp = 0;
    for ind = 1:1+strcmp(opt.prfmodel,'DoG')
        PredResp = PredResp + sign((ind<2)-.5) * RF.amp(ind) * UnwrappedConvStim(:,:,runNum)*Gauss(RF,s.x,s.y,ind,1);
    end
    PredResp = RF.offset + PredResp;
    correl = correl + mycorr(ObsResp(:,runNum),PredResp);
end
err = - (correl / size(UnwrappedConvStim,3));

%% constraints
if isfinite(opt.constrainfit2maxEccDeg)
    ecclim = opt.constrainfit2maxEccDeg;
    n = length(s.x);
    minsig = ecclim/n;
    err = err + 1000*(abs(min(RF.sig,minsig)-minsig))^2; % cost on small sigmas
    
    [~, ecc] = cart2pol(RF.center(:,1),RF.center(:,2));
    err = err + 1000*(max(ecc,(ecclim+2))-(ecclim+2))^2; % cost on ecc > stimulated area
end

% add constraints specific to the DoG model
if strcmp(opt.prfmodel,'DoG')
    % the amplitude of the negative component must be smaller than the amplitude of the positive one
    err = err + 1000*max(0,diff(RF.amp))^2;
    % the sigma of the negative component must be equal or smaller than the sigma of the positive one
    err = err + 1000*max(0,-diff(RF.sig))^2;
end
