cls
file{1} = load( 'myprfs_corr.mat' );
file{2} = load( 'myprfs_mse.mat' );



%% load values
for f = 1:length(file)+1
    if f <= length(file)
        pRFs = file{f}.pRFs;
        id = cat(1,pRFs(:).id);
%         gof = cat(1,pRFs(:).co);
        if strcmp(file{f}.opt.gof,'mse'), 
            gof = (cat(1,pRFs(:).err)); 
        else
            gof = -cat(1,pRFs(:).co); 
        end; 
    else
        pRFs = file{1}.knownPRFs;
        id = cat(1,pRFs(:).offset) * NaN;
        gof = cat(1,pRFs(:).co);
    end
    
    center = cat(1,pRFs(:).center);
    sig = cat(1,pRFs(:).sig);
    [polang ecc] = cart2pol(center(:,1),center(:,2));
    % polang = cos(polang);
    polang = polang/pi;
    
        
    myprfs = cat(2,center,ecc,polang,sig,gof,id);
    
    prfs{f} = myprfs;
    
end
vals{1} = 'x';
vals{2} = 'y';
vals{3} = 'ecc';
vals{4} = 'polang';
vals{5} = 'sig1';
vals{6} = 'sig2';
vals{7} = 'gof';
vals{8} = 'voxel';

colors = {[1 0 0];[0 1 0]};
shapes = {'.';'o'};

%% compare values to real
figure(1); clf
vals_to_plot = [3 4 5];

for f = 1:length(prfs)-1
    ct = 0;
    for i = vals_to_plot
        ct = ct + 1;
        
        subplot(1,length(vals_to_plot),ct); hold on
        
%         if i ~= 7
            plot(prfs{end}(:,i),prfs{f}(:,i),shapes{f},'color',colors{f})
        a = axis; a = [min(a([1 3])) max(a([2 4]))];
        plot(a,a)
%         else
%             plot(prfs{1}(:,i),prfs{2}(:,i),'.')
%         end

        xlabel(vals{i})
        axis square
    end
end
% return
%% compare values
figure(2); clf
vals_to_plot =  [7];
ct = 0;
for i = vals_to_plot
    ct = ct + 1;
    difference = prfs{1}(:,i) - prfs{2}(:,i) ;
    subplot(1,length(vals_to_plot)+1,ct); hold on
    
    
    if i~=7
        plot(prfs{1}(:,i),difference,'.')
        a = axis; a = [min(a([1 3])) max(a([2 4]))];
        plot(a,a*0)
        ylabel('diff')
    else
        plot(prfs{1}(:,i),prfs{2}(:,i),'.')
    end
    
    xlabel(vals{i})
    axis square
end


