function [pRFs HDR opt pRFs_ihdr misc] = ccpRF_Estimate(vtc,stim,s,lrs,opt)
%
% 2012/10 - modified from pRF_Estimate function
%
%
% inputs:
%
% vtc -> fMRI data
%     vtc(1:nvoxels).tc (2D vector, rows=TRs, columns=runs)
%     vtc(1:nvoxels).id (Voxel indices, useful for vmp creation)
%
% stim ->
%       .secPerTR   - TR duration in seconds
%       .numTRs     - stim.durSec / stim.secPerTr
%
% s  -> stimulus movie with the following fields:
%     s.frames (the stimulus) [4D: x,y,timeinarun,differentruns]
%     s.x and s.y (meshgrid)
%     s.nx and s.ny (length of x and y)
% 	  s.dx and s.dy (steps in degrees)
%
% opt -> optional inputs
%     [opt.gof ('corr','mse') measure of goodness of fit ] default is 'corr'
%     [opt.prfmodel ('Gauss','DoG') pRF model] default is 'Gauss'
%     [opt.corrthr (if max(corr(resp,seedsMat))>thr, do nonlinear
%             fitting, else put NaN)] default is 0.25
%     [opt.findscaling (1/0) use polyval to find amplitude and offset
%             that, given each pRF, best explain the fMRI timecourse. not free
%             parameters.] default is 1
%     [opt.parallel (1/0) use parallelization toolbox] default is 0
%     [opt.constrainfit2maxEccDeg  (deg)   - force fit to avoid sig values smaller than
%               the stimulus matrix resolution and eccentricity values
%               larger than maximum tested eccentricity] default is Inf
%     [opt.estimatehdr -> DISABLED. always set to 0]
%     [opt.hdr (.tau and .delay params to fit pRFs, or initialize the iterative hdr fitting)] default is Boynton '96
%     [opt.vtcsize (4D size of original BV vtc, useful for vmp creation)] default is []
%
%
%
% outputs:
%
% pRFs -> 3 kinds of variables: fitted (center and sig + tau and delay if opt.estimatehdr),
%         estimated after fitting the prf (co, amp and offset) and copies of preset values (id)
%     pRFs(1:nvoxels).center : x,y position
%     pRFs(1:nvoxels).sig : sigma (of the pos,neg lobe if pRF model is DoG; only pos lobe if model is Gauss)
%     pRFs(1:nvoxels).co : correlation
% 	  pRFs(1:nvoxels).amp : scaling factor (not a free param)
%     pRFs(1:nvoxels).offset : offset (not a free param and not a property of the pRF .. just dc of fMRI timecourse)
%     pRFs(1:nvoxels).id : voxel id (copied from vtc(:).id)
%
% HDR -> estimated (if opt.estimatehdr) or Boynton '96
%     HDR.tau
%     HDR.delay
%     HDR.n
%     HDR.dt
%     HDR.th
%     HDR.function
%
% opt -> as in input, but updated with defaults
%
% pRFs_ihdr -> if opt.estimatehdr, a subset of voxels is selected,
%       where pRF and HDR are simultaneously estimated (iterative procedure).
%       The median of fitted tau and delay parameters is then used to
%       recompute the hdr for the final pRFs fitting. Fields of the pRFs_ihdr structure
%       are (non NaNs only for the selected subset of voxels and if opt.estimatehdr):
%       .center, .sig, -> parameters of the iteratively fitted pRF
%       .tau, .delay, -> parameters of the iteratively fitted hdr
%       .co -> correlation of the fit of pRF and hdr
%       .id
%
% misc ->
%     misc.pRFestimation_time (in s)
%     misc.hdrestimation_time (in s) -> NaN if ~opt.estimatehdr
%
%
% functions required:
% UW_toolbox/Optimization (fit interface)
% Gamma.m (Geoff's) -> rename the function capitalizing the initial to
%                                           avoid conflict with Matlab built-in function
% fitPRF_corr.m
% fitPRF_mse.m
% Gauss.m
% mycorr.m (Paola's correlation)
%
%
%
% Paola, 2012/02/18


%% set defaults
lrs = [];
opt.estimatehdr = 0; 
if ~isfield(opt,'corrthr'), opt.corrthr = 0.25; end
if ~isfield(opt,'parallel'), opt.parallel = 0; end
if ~isfield(opt,'findscaling'), opt.findscaling = 1; end
if ~isfield(opt,'constrainfit2maxEccDeg'), opt.constrainfit2maxEccDeg = Inf; end
if ~isfield(opt,'vtcsize'), opt.vtcsize = []; end
if ~isfield(opt,'gof'), opt.gof = 'corr'; end
if ~isfield(opt,'prfmodel'), opt.prfmodel = 'Gauss'; end
if isfield(opt,'hdr')
    HDR = opt.hdr;
else %  Boynton et al. '96
    HDR.tau = 1.5; %seconds
    HDR.delay = 2.25;  %seconds
end
opt_gofcorr = opt; opt_gofcorr.gof = 'corr';
opt_gofmse = opt; opt_gofmse.gof = 'mse';

if strcmp(opt.gof,'mse')
    opt.findscaling = 0;
end
if strcmp(opt.prfmodel,'Gauss')
    indfrelist = '(1)';
elseif strcmp(opt.prfmodel,'DoG')
    indfrelist = '(1:2)';
else
    error('prfmodel unknown')
end

HDR.n = 3;
HDR.dt = stim.secPerTR;
HDR.th = 0:HDR.dt:30;
HDR.function = shiftdim(Gamma(HDR.n,HDR.tau,HDR.th-HDR.delay),-1);  %use shiftdim to make it a 1x1xn vector

%% Create stimulus timecourses convolved by HDR
% if opt.estimatehdr , will be overwritten
disp('creating predicted timecourses ...')
tic

% loop through the n different Runs (saved as 4th dimension of s.frames),
% convolve stimuli timecourses with hdr, collapse the 2 spatial dimensions
% into one 

UnwrappedConvStim = [];
for nR = 1:size(s.frames,4) %different runs
    % convolve the time-course of each pixel in the stimulus with the HDR.
    ConvStim = stim.secPerTR*convn(s.frames(:,:,:,nR),HDR.function); ConvStim = ConvStim(:,:,1:stim.numTRs);  %truncate the extra padding after the convolution
    % unwrap the 3D matrix (x,y,time) into a 2D matrix (time,space) + 3rd dimension: different runs
    UnwrappedConvStim = cat( 3,UnwrappedConvStim,    s.dx*s.dy*reshape(ConvStim,[s.nx*s.ny,stim.numTRs])'     ); clear ConvStim
end
if any(size(vtc(1).tc) ~= [size(UnwrappedConvStim,1) size(UnwrappedConvStim,3)])
    error('stim dimension and vtc dimensions do not match')
end

%% Seeds for fit initialization
%
% define a series of potential pRFs that are used as starting
% points for the nonlinear optimization process. Here,
% one every 0.5 deg x 1:2:10 sigma 
step = 0.5; 
seedX = min(s.x(:)) : step : max(s.x(:));
seedY = min(s.y(:)) : step : max(s.y(:));
seedSig = linspace(1,10,5); %
% create all possible combinations
[xList,yList,sigList] = ndgrid(seedX,seedY,seedSig);
% unwrap into 1D vectors length(seedX)*length(seedY)*length(seedSig) long
xList = xList(:);
yList = yList(:);
sigList = sigList(:);

% columns of matSeeds will hold the unwrapped Gaussian pRFs
% matrix size: [s.nx*s.ny , length(seedX)*length(seedY)*length(seedSig), Number of runs]
% this is where OUT OF MEMORY is likely to occur. decrease s.nx and ny to fix
SeedsPredResp = zeros(size(UnwrappedConvStim,1),length(xList),size(UnwrappedConvStim,3));

for i = 1:length(xList)
    seedRF(i).center = [xList(i),yList(i)];
    
    if strcmp(opt.prfmodel,'DoG')
        seedRF(i).sig = [sigList(i) 2*sigList(i)];
        seedRF(i).amp = [1 .5];
    else
        seedRF(i).sig = [sigList(i) NaN];
        seedRF(i).amp = [1 NaN];
    end
    seedRF(i).offset = 0;
    seedRF(i).shutup = 1;
    seedRF(i).co = NaN;
    seedRF(i).id = NaN;
    
    
    RF = seedRF(i);
    
    
    for runNum = 1:size(UnwrappedConvStim,3)
        PredResp = 0;
        for ind = 1:1+strcmp(opt.prfmodel,'DoG')
            PredResp = PredResp + sign((ind<2)-.5) * RF.amp(ind) * UnwrappedConvStim(:,:,runNum)*Gauss(RF,s.x,s.y,ind,1);
        end
        % each column is the time course predicted by one seedRF
        SeedsPredResp(:,i,runNum) = PredResp;
    end
    
    if ~mod(i,100), fprintf('..%i..',i); end
end



%% initialize pRF structures
% takes no time and reduces clutter in the parfor loop
parfor voxNum = 1:length(vtc)
    
    % pRFs
    pRFs(voxNum).center = [NaN NaN]; % x,y
    pRFs(voxNum).sig = [NaN NaN]; % pos and neg lobe (if pRF model is DoG)
    pRFs(voxNum).co = NaN;
    pRFs(voxNum).err = NaN;
    pRFs(voxNum).amp = [NaN NaN];
    pRFs(voxNum).offset = NaN;
    pRFs(voxNum).id = NaN;
    
end
misc.hdrestimation_time = NaN;
toc

%% estimate iHDR -> removed 2012.06.05
pRFs_ihdr = [];

%% estimate pRFs
% initialize progress monitor bar -> dwnld free pkg "ParforProgMon"
if opt.parallel, ppm = ParforProgMon([ 'pRF fitting started at '  datestr(now,'HH:MM')], length(vtc) ); else ppm.increment = NaN; end
tic
disp('start pRFestimate, looping through voxels ...')

if strcmp(opt.gof,'corr')
    parfor voxNum = 1:length(vtc)
        
        % initializations required by parfor
        vN = voxNum;
        ObsResp = vtc(vN).tc;
        
        % show current status
        if ~opt.parallel, fprintf('voxNum %d of %d \n',vN,size(vtc,2)); end
        ppm.increment();
        
        % save voxel .id in pRF struct
        pRFs(voxNum).id = vtc(vN).id;
        
        % find best seed to initialize pRF fitting
        basiscorr = 0;
        for runNum = 1:size(UnwrappedConvStim,3)
            basiscorr = basiscorr + mycorr(ObsResp(:,runNum),SeedsPredResp);
        end
        basiscorr = basiscorr / size(UnwrappedConvStim,3);
        [maxcorr bestseed] = max(basiscorr);
        
        if maxcorr < opt.corrthr
            pRFs(voxNum).co = maxcorr;
            
        else
            disp(sprintf('..%i..',vN))
            
            [tmpRF err] = fit('fitPRF_corr',seedRF(bestseed),{'center','sig'},UnwrappedConvStim,ObsResp,s,opt);
            pRFs(voxNum).co = -err;
            
            
            pRFs(voxNum).center = tmpRF.center;
            pRFs(voxNum).sig = tmpRF.sig;
            
            if opt.findscaling
%                 error('opt.findscaling no longer implemented')
                % find scaling and offset that best explain the ObsResp given the
                % fitted pRF (only if opt.gof = 'corr')
                if strcmp(opt.prfmodel,'Gauss')
                    a = 0; b = 0;
                    for runNum = 1:size(UnwrappedConvStim,3)
                        PredResp = UnwrappedConvStim(:,:,runNum)*Gauss(tmpRF,s.x,s.y,1,1);
                        polyVals = polyfit(PredResp,ObsResp(:,runNum),1);
                        a = a + polyVals(1);
                        b = b + polyVals(2);
                    end
                    % use mean across runs
                    tmpRF.amp = [a / size(UnwrappedConvStim,3) NaN];
                    tmpRF.offset = b / size(UnwrappedConvStim,3);
                elseif strcmp(opt.prfmodel,'DoG')
                    [tmpRF err] = fit('fitPRF_mse',tmpRF,{['amp' indfrelist],'offset'},UnwrappedConvStim,ObsResp,s,opt);
                end
                % estimate error (no actual fitting)
                [tmpRF err] = fit('fitPRF_mse',tmpRF,{},UnwrappedConvStim,ObsResp,s,opt);
                pRFs(voxNum).err = err;
                
                pRFs(voxNum).amp = tmpRF.amp;
                pRFs(voxNum).offset = tmpRF.offset;
            end
            
        end
    end
elseif strcmp(opt.gof,'mse') % mse fitting
%     error('opt.gof = mse no longer implemented')
    parfor voxNum = 1:length(vtc)
        
        % initializations required by parfor
        vN = voxNum;
        ObsResp = vtc(vN).tc;
        
        % show current status
        if ~opt.parallel, fprintf('voxNum %d of %d \n',vN,size(vtc,2)); end
        ppm.increment();
        
        % save voxel .id in pRF struct
        pRFs(voxNum).id = vtc(vN).id;
        
        % find best seed to initialize pRF fitting
        basiscorr = 0;
        for runNum = 1:size(UnwrappedConvStim,3)
            basiscorr = basiscorr + mycorr(ObsResp(:,runNum),SeedsPredResp);
        end
        basiscorr = basiscorr / size(UnwrappedConvStim,3);
        [maxcorr bestseed] = max(basiscorr);
        
        if maxcorr < opt.corrthr
            pRFs(voxNum).co = maxcorr;
            
        else
            disp(sprintf('..%i..',vN))
            tmpRF = seedRF(bestseed);
            % estimate amplitude and offset paramters given the best 'seed pRF'
            if strcmp(opt.prfmodel,'Gauss')
                a = 0; b = 0;
                for runNum = 1:size(UnwrappedConvStim,3)
                    PredResp = UnwrappedConvStim(:,:,runNum)*Gauss(tmpRF,s.x,s.y,1,1);
                    polyVals = polyfit(PredResp,ObsResp(:,runNum),1);
                    a = a + polyVals(1);
                    b = b + polyVals(2);
                end
                % use mean across runs
                tmpRF.amp = [a / size(UnwrappedConvStim,3) NaN];
                tmpRF.offset = b / size(UnwrappedConvStim,3);
            elseif strcmp(opt.prfmodel,'DoG')
                tmpRF = fit('fitPRF_mse',tmpRF,{['amp' indfrelist],'offset'},UnwrappedConvStim,ObsResp,s,opt);
            end
            
            % fit of all parameters
            [tmpRF err] = fit('fitPRF_mse',tmpRF,{'center',['sig' indfrelist],['amp' indfrelist],'offset'},UnwrappedConvStim,ObsResp,s,opt);
%             [tmpRF err] = fit('fitPRF_mse',tmpRF,{'center',['sig' indfrelist]},UnwrappedConvStim,ObsResp,s,opt);
            pRFs(voxNum).err = err;
            
            % estimate correlation as well
            [tmpRF err] = fit('fitPRF_corr',tmpRF,{},UnwrappedConvStim,ObsResp,s,opt_gofcorr);
            pRFs(voxNum).co = -err;
            
            pRFs(voxNum).center = tmpRF.center;
            pRFs(voxNum).sig = tmpRF.sig;
            pRFs(voxNum).amp = tmpRF.amp;
            pRFs(voxNum).offset = tmpRF.offset;
            
        end
    end
else
    error('unkonwn opt.gof (goodness of fit index) parameter')
end
misc.pRFestimation_time = toc;

disp(sprintf('\n prf estimation completed in %i min \n', round(misc.pRFestimation_time/60)))
fprintf('\n\n\n')


