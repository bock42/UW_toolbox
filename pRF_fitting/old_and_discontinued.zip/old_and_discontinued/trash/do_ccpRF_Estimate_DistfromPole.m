% create 'true pRFs' (generate responses, set options, etc) to recover with pRF_Estimate
% for cortico-cortical prfs

clear all; close all; clc;
seed = 1; rand('seed',seed); randn('seed',seed);

% set noiselevel
noiselevel = 0; %.1 corresponds to co about .6   .2 -> .4  .05 -> .85

% set optional inputs to pRF_Estimate
% type help pRF_Estimate for the list of available options
opt.vtcsize = NaN * [1 36 26 48]; % time,3D -> whole brain (it's freesurfer, this won't work)
opt.parallel = 1;
% opt.corrthr = 1;
opt.findscaling = 0;
% opt.prfmodel = 'DoG';
% opt.gof = 'mse';
opt.rate4seeds = 1;
opt.reload_predresps = 1;


ind = 1; % for Gauss rather than DoG

%% define space & time
load('Andrew.mat','Vertices','Dist')

hemi = {'lh','rh'};
hh = 1; % left hemi only

% find out max distance (for colormaps)
alldist = cat(1,Dist{1,1},Dist{1,2});
maxdist = max(alldist);

mystep = 1;%round(length(Dist{1,hh})/50);
analyzed_vertices = 1 : mystep : length(Dist{1,hh}); % for simulation, consider only part of V1

% s -> V1 data
%     .x        distances from pole [1:nVx_V1, 1]
%     .y        1 (placeholder)
%     .nx,.ny   length x,y
%     .dx,.dy   1,1 (never used)
%     .id       surface vertex identifier (for plotting) -- this is an extra-field, not present for in stimbased analysis
%     .frames	timecourses [1:nVx_V1, 1, nTRs]

s.x = Dist{1,hh}(analyzed_vertices);
s.y = 1;
s.nx = length( s.x ) ;
s.ny = 1 ;
s.dx = 1;
s.dy = 1;
s.id = Vertices{1,hh}(analyzed_vertices);


%% define stimulus

% spatiotemporal matrix (each vertex in V1 is on at one timepoint only, alone)
stim.numTRs = numel(s.x);
s.frames = zeros(s.nx,s.ny,stim.numTRs);
for t = 1:stim.numTRs
    tmp = s.frames(:,:,t);
    tmp(t) = 1;
    s.frames(:,:,t) = tmp;
end
lrs = s;
% chose which stimulus actually drives resps and which one is used for the fit
actualStim = s.frames; 
stimForfit = s.frames;

%% convolve with hdr & unwrap
stim.secPerTR = 1; % never used unless there is convolution  
HDR.dt = 1;
HDR.function = 1; % this way there is no convolution going on
opt.hdr = HDR;

CStim = HDR.dt * convn(actualStim,HDR.function);
CStim = CStim(:,:,1:stim.numTRs);  %truncate the extra padding after the convolution

% unwrap the 3D matrix (x,y,time) into a 2D matrix (space,time)
UCStim = s.dx*s.dy*reshape(CStim,[s.nx*s.ny, stim.numTRs])';

%% define true pRFs
y = 0;
step = 25;
xList = 20;%round(min(s.x(:))) : step : round(max(s.x(:))); length(xList)
sigList = 5;%linspace(1,round(max(s.x(:)))/4,2); length(sigList)
ampList = ones(size(xList));
offList = ones(size(xList));
unwrap = 0;
vx = 0;
for cs = 1:length(sigList)
    for cx = 1:length(xList)
        vx = vx + 1;
        tRF(vx).center = [xList(cx) y];
        tRF(vx).sig = [sigList(cs) NaN];
        tRF(vx).co = NaN;
        tRF(vx).amp = [ampList(cx) NaN];
        tRF(vx).offset = offList(cx);
        
        myfun = Gauss( tRF(vx), s.x, s.y, ind, unwrap );
        if cx==1 && cs == 1
            myfun_bu = myfun;
        end
        % noise proportional to sigma and amp (its effect should be approx constant)
        tRF(vx).noisecoeff = noiselevel * sigList(cs).^.5 * max(myfun(:)) * tRF(vx).amp(ind);
    end
end
nVx = length(tRF);

%% create responses
myv2vx = Vertices{2,hh};
myv2vx = Shuffle(myv2vx); % distribute the simulated timecourses randomly across V2
for vx = 1:nVx
    vtc(vx).id = myv2vx(vx);
    % save the timecourse that is passed to pRF_Estimate
    unwrap = 1;
    myresp = UCStim * Gauss( tRF(vx), s.x, s.y, ind, unwrap );
    noise = randn(size(myresp)) * tRF(vx).noisecoeff;
    vtc(vx).tc = myresp * tRF(vx).amp(ind) + tRF(vx).offset + noise;
end

% %% call pRF_estimate (and open parallel pool, if an option)
% if opt.parallel
%     if matlabpool('size') == 0 % checking to see if my pool is already open
%         matlabpool open 6 % number of cores you have
%     end
%     currdir = cd('../Parallelization/ParforProgMon/'); 
%     pctRunOnAll javaaddpath(cd)
%     cd(currdir)
%     
%     try  jm = findResource('scheduler', 'configuration', defaultParallelConfig);
%     catch me
%         parallel = 0;
%     end
%     
% end
% disp('calling pRF_estimate function...')
% [pRFs HDR opt pRFs_ihdr misc] = pRF_Estimate(vtc,stim,s,lrs,opt);
% 
% output_filename = 'myprfs.mat';
% save(output_filename, 'pRFs', 'HDR', 'opt', 'pRFs_ihdr', 'misc', 'tRF', 'vtc');
% 
% 
% %% plot results
% trueRFs = [cat(1,tRF.center) cat(1,tRF.sig) cat(1,tRF.noisecoeff) cat(1,tRF.amp) cat(1,tRF.offset)];
% estRFs = [cat(1,pRFs.center) cat(1,pRFs.sig) cat(1,pRFs.co) cat(1,pRFs.amp) cat(1,pRFs.offset)];
% mycols = [1 3 5 6 8]; % x,sig,corr
% mycolors = hsv(length(sigList));
% 
% % all together
% figure(1); clf; set(gcf,'position',[360,9,340,913;])
% for i = 1:length(mycols)
%     subplot(length(mycols),1,i); hold on
%     myx = trueRFs(:,mycols(i)); % ecc
%     myy = estRFs(:,mycols(i));
%     plot(myx,myy,'.','color',mycolors(cs,:));
%     plot(myx,myx,':k')
% end
% 
% % group by sigma vals and plot against eccentricity
% figure(2); clf; set(gcf,'position',[360+300,9,340,913;])
% for cs = 1:length(sigList)
%     thisSig = sigList(cs);
%     myleg{cs} = num2str(thisSig);
%     ind = trueRFs(:,3) == thisSig;
%     
%     mytrue = trueRFs(ind,:);
%     myest = estRFs(ind,:);
%     
%     for i = 1:length(mycols)
%         subplot(length(mycols),1,i); hold on
%         myx = mytrue(:,mycols(1)); % ecc
%         myy = myest(:,mycols(i));
%         h(cs) = plot(myx,myy,'.-','color',mycolors(cs,:));
%         if i == 1
%             plot(myx,myx,':k')
%         else
%             plot(myx,myx*0+myy(end),':','color',mycolors(cs,:))
%         end
%     end
%     
% end
% legend(h,myleg)

%% plot on brain surface
mydir = '/home/pbinda1/Andrew/files_for_Paola/';

% load brains
currdir = cd(mydir); % go to directory where these fs functions are
[vert,face] = freesurfer_read_surf( strcat(mydir,hemi{hh},'.','inflated') );
[curv,~] = freesurfer_read_curv( strcat(mydir,hemi{hh},'.','curv') );
cd(currdir) % come back
% basic colomap: just the curvature
cmap_curv = -[ curv, curv, curv ];
% put all into a patch structure
brain.vertices = vert;
brain.faces = face;
brain.facevertexcdata = cmap_curv;


% substitute indices in V1 with Dist (i.e. x) values
% analyzed_vertices = 1:length(Vertices{1,hh});
myV1 = s.id;
mydist = s.x/maxdist;
cmap1 = cmap_curv;
cmap1(myV1,1) = mydist;
cmap1(myV1,2) = 1-mydist;
% put into patch
smp1 = brain;
smp1.facevertexcdata = cmap1;
myalpha1 = zeros(size(cmap1,1),1); myalpha1(myV1) = 1;% set to transparent all the non-mapped vertices

% % substitute indices in V2 with estimated Dist (i.e. x) values
% myV2 = cat(1,vtc.id);
% mydist = cat(1,pRFs.center); mydist = mydist(:,1);
% cmap2 = cmap_curv;
% cmap2(myV2,1) = mydist;
% cmap2(myV2,2) = 1-mydist;
% % put into patch
% smp2 = brain;
% smp2.facevertexcdata = cmap2;
% myalpha2 = zeros(size(cmap1,1),1); myalpha2(myV2) = 1;% set to transparent all the non-mapped vertices
% 
% % plot all
% figure(100); clf; hold on
% patch(brain,'EdgeColor','none','facecolor','interp','FaceAlpha',1);
% patch(smp1,'EdgeColor','none','facecolor','interp','FaceAlpha','flat','FaceVertexAlphaData',myalpha1);
% patch(smp2,'EdgeColor','none','facecolor','interp','FaceAlpha','flat','FaceVertexAlphaData',myalpha2);
% 
% daspect([1 1 1]); camproj perspective;
% if strcmp(hemi{hh},'lh'), view(40,0); else view(-40,0); end;
% axis off

%% plot the last pRF
load('tmp.mat','mydata')

cmap1 = cmap_curv;
% cmap1(myV1,1) = myfun_bu/max(myfun_bu);
% cmap1(myV1,2) = 1-(myfun_bu/max(myfun_bu));


cmap1(:,1) = mydata/max(mydata);
cmap1(:,2) = 1 - (mydata/max(mydata));
smp1.facevertexcdata = cmap1;

% plot all
figure(101); clf; hold on
patch(brain,'EdgeColor','none','facecolor','interp','FaceAlpha',1);
patch(smp1,'EdgeColor','none','facecolor','interp','FaceAlpha','flat','FaceVertexAlphaData',myalpha1);
daspect([1 1 1]); camproj perspective;
if strcmp(hemi{hh},'lh'), view(40,0); else view(-40,0); end;
axis off



