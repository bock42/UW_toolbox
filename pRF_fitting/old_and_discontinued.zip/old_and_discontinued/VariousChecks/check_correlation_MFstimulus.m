% check correlation structure in stim.activeRegions
cls
load MFStimLayoutAndSequence.mat

allvals = randn(5,100);
allvals = stimSeq;

%%

for i = 1:size(allvals,1)
    for j = 1:size(allvals,1)
        
        tmp = corrcoef(allvals(i,:),allvals(j,:))
        
        cc(i,j) = tmp(2);
        
    end
end


%%
for i = 1:size(allvals,1)
    cc(:,i) = mycorr( allvals(i,:)',allvals' );
end

%%
cc
close all
imagesc(cc)
