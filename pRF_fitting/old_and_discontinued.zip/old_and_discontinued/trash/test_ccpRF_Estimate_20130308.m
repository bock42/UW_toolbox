cls
addpath('myfunctions/')
%% load data

functdatadir = [cd '/MRdata/functional/'];
d = dir([functdatadir '*00*']); 
nruns = length(d);


hemi = {'lh';'rh'};
rois = {'V1';'V2'};

Timecourses = cell(length(rois),length(hemi));

for hh = 1:2
    % load timecourses for all vertices
    for thisrun = 1:nruns
        thisfile = [functdatadir '00' num2str(thisrun) '/rf.156.tf_surf.' hemi{hh} '.nii.gz'];
        tmp = load_nifti(thisfile);
        allbrain = tmp.vol;
        for thisroi = 1:length(rois)
            return
            Timecourses{thisroi,hh} = allbrain(Vertices{thisroi,hh},:,:,:);
        end
    end
end