% example script to set up the input for pRF_estimate.m
%
% simulates timecourses based on known pRFs and HDR, then tests if
% pRF_estimate recovers those values.
%
% uses Zach's functions to generate the stimulus (moving bar):
% getBarSequence.m
% makeStimulusMovie.m
%
% Paola, 2012/02/18

% log changes
% 2012/02/22 ZRE, modified to use standardized toolset,
% 2012/02/23 PB, display.dist -> Zach, I think this should be 68cm!!

clear all; close all; clc;
seed = 3;
rand('seed',seed)
randn('seed',seed)
% 0 = run pRF estimate; 1 = show mean and var of the stimulus; 
% 2 = show stimulus movie; 3 = space average over time
visualize_stimulus_only = 0;
stim.scotoma.flag = 0;

nruns = 2; % number of runs

% NOTE:
% makeStimulusMovie flips up-down the drifing bar stimulus -- this does not happen for the multifocal stimulus

% number of voxels to simulate
nVx = 50;
% set amplitude of randn(1:nTRs) added to the fMRI timecourse of each voxel from its (known) pRF
rndmnoise = .05*0;
% downsample of stimulus space -> n of pixel where the stim is defined: nPix = round(display.resolution/dwns);
dwns = 20;
% timecourse created assuming a DoG prf 
prf_DoG = 0;

%% set optional inputs to pRF_Estimate
% type help pRF_Estimate for the list of available options
opt.vtcsize = [1 36 26 48]; % time,3D -> whole brain
opt.parallel = 1;
% opt.corrthr = 1;
% opt.findscaling = 0;
% opt.prfmodel = 'DoG';
opt.gof = 'corr';%'mse';

%% start
if 1% set pRF params (which the fit will recover)
    
    centersList = [ (rand(nVx,1)-0.5)*5  (rand(nVx,1)-0.5)*5 ];
    sigList = .5+rand(nVx,1)*2; 
    sigList(:,2) = sigList(:,1) + 1;
    ampList = rand(nVx,1)*10; ampList(:,2) = ampList(:,1)*.5; % amplitude of the signal
    offsetList = randn(nVx,1) * 1; % offset of the fMRI timecourse
    noiseList = rand(nVx,1) * 0+0.0;

else % or, load prfs estimates
    [filename pathname] = uigetfile('*.mat');
    load([pathname filename],'pRFs')
    nVx = length(pRFs);
    centersList = cat(1,pRFs.center);
    sigList = cat(1,pRFs.sig);
    ampList = ones(nVx,1); % amplitude of the signal
    offsetList = zeros(nVx,1); % offset of the fMRI timecourse
end

if ~prf_DoG
    sigList(:,2) = NaN;
    ampList(:,2) = NaN;
end

homedir = cd;
targetdir = '/data/tmp/';
d = dir([homedir targetdir '*.mat']); stimulus_file = [homedir targetdir d(2).name];disp(stimulus_file)

%% make the stimulus sequence
% randomly moving bar
if 1*exist('stimulus_file','var')
    load(stimulus_file)
    disp('loading stimulus ...')
else % generate a random sequence of drifting bars
    stim.secPerTR = 1;
    stim.numTRs = 252;
    stim.seed = 1; % so that you always generate the same sequence on subsequent calls of this script
    stim.degPerSecRange = [ 1.25 1.75 ]; % speed range
    stim.durBlanksSec = 12;
    stim.nSweepsBetweenBlanks = 3;
    
    stim.scotoma.center = [0 0];
    stim.scotoma.rad = [1 1] * 5;
    
    stim.widthDeg = 5; % width of bar
    stim.radDeg = 16; % radius of aperture
    stim.fixMaskRadDeg = 1.5; % mask of fixation spot
    
    display.resolution = [1024 768]; % normaly set by OpenWindow
    display.dist = 68; %60;     %distance from screen (cm)
    display.width = 33;  %width of screen (cm)
    display.screenAngle = pix2angle( display, display.resolution );
    display.center = floor(display.resolution/2);

    stim = getBarSequence(stim);

%     stim.StimulusType = 'ExpandingRing';
%     stim = getRingSequence(stim);
end
% trim display to fit the stimulus tightly

stim_max_diam_deg = 2*max(stim.radDeg);
equiv_screen_width = stim_max_diam_deg / display.screenAngle(2) * display.screenAngle(1) ;
display.screenAngle = [equiv_screen_width stim_max_diam_deg];
display.width =  2 * display.dist * tan( pi * display.screenAngle(1) / (2*180) ) ;

%% make stimulus movie
% movie used to predict the fMRI timecourse, hence fit pRFs
% use a resolution lower than that of the screen (we don't need to predict
% the timecourse of fMRI data for each pixel)
% I've found that 4 pixels per degree is ok
nPix = round(display.resolution/dwns);

% stimulus movie 
s = makeStimulusMovie( display, stim, 1*nPix );
s.frames = repmat(s.frames,[1 1 1 nruns]);

lrs = []; %makeStimulusMovie( display, stim, nPix );

if visualize_stimulus_only 
    
    if 0
    elseif visualize_stimulus_only==1 % statistics
        figure(2); clf
        subplot(1,2,1); title('mean'); hold on
        imagesc(s.x(1,:),s.y(:,1),mean(s.frames,3));
        axis equal %off
        colorbar
        subplot(1,2,2); title('variance'); hold on
        imagesc(s.x(1,:),s.y(:,1),var(s.frames,[],3));
        axis equal %off
        colorbar
        drawnow
    elseif visualize_stimulus_only==2 %  stimulus movie
        figure(1); clf;
        for fr = 1 : stim.numTRs
            title( fr )
            hold on
            image( s.x(1,:), s.y(:,1), s.frames(:,:,fr) * 255)
            pause(.2)
            axis equal
            
        end
    elseif visualize_stimulus_only==3 %  space average over time
        figure(1); clf;
        avg = squeeze(mean(mean(s.frames,1),2));
        plot(avg,'.-')
        xlabel('time (fr)')
        ylabel('average stimulus contrast across space')
        sum(avg==0)/length(avg)
    end
    return
end

%% simulate the fMRI timecourse
% set parameters useful for saving pRF values into a vtc
voi = 1:nVx; % -> indices identifying the voxels in my voi

% set hdr params (which the fit will recover, if opt.estimatehdr)
% use Boynton '96 (the default of pRF_Estimate function)
HDR.tau = 1.5; %seconds
HDR.delay = 2.25;  %seconds

% % change tau and delay
% HDR.tau = HDR.tau - .5;
HDR.delay = HDR.delay - .5;

HDR.n = 3;
HDR.dt = stim.secPerTR;
HDR.th = 0:HDR.dt:30;
HDR.function = shiftdim(Gamma( HDR.n, HDR.tau, HDR.th-HDR.delay ),-1);  %use shiftdim to make it a 1x1xn vector

% convolve the time-course of each pixel in the stimulus with the HDR.
ConvStim = HDR.dt * convn(s.frames,HDR.function);
ConvStim = ConvStim(:,:,1:stim.numTRs);  %truncate the extra padding after the convolution

% unwrap the 3D matrix (x,y,time) into a 2D matrix (space,time)
UnwrappedConvStim = s.dx*s.dy*reshape(ConvStim,[s.nx*s.ny, stim.numTRs])';
clear ConvStim

for voxNum = 1:nVx
    knownPRFs(voxNum).center = centersList(voxNum,:);
    knownPRFs(voxNum).sig = sigList(voxNum,:);
    knownPRFs(voxNum).amp = ampList(voxNum,:);
    knownPRFs(voxNum).offset = offsetList(voxNum);
    
    
    % timecourse of the vx voxel
    for runNum = 1:nruns
        tc = 0;
        for innd = 1:1+(prf_DoG>0)
            tc = tc + sign((innd<2)-.5)*knownPRFs(voxNum).amp(innd) * UnwrappedConvStim * Gauss( knownPRFs(voxNum), s.x, s.y, innd, 1 );
        end
        tc = tc + knownPRFs(voxNum).offset; % shift baseline
        noise = noiseList(voxNum)*randn(size( tc ));
        knownPRFs(voxNum).co = noiseList(voxNum);
        vtc(voxNum).tc(:,runNum) = tc + noise; % add randn noise
    end
    % voxel identifier (only for .vmp creation)
    vtc(voxNum).id = voi(voxNum);
    
    % legend (to show pRF parameters for each fMRI timecourse)
    leg{voxNum} = num2str([cat(1,knownPRFs(voxNum).center) knownPRFs(voxNum).sig]);
end

% plot timecourses
if 1
    figure(100); clf; hold on
    bla=cat(2,vtc(:).tc);
    plot(bla);
    xlim([0 240])
    legend(leg)
    drawnow
end


%% call pRF_estimate (and open parallel pool, if an option)
if opt.parallel
    if matlabpool('size') == 0 % checking to see if my pool is already open
        matlabpool open 6 % number of cores you have
    end
    currdir = cd('../Parallelization/ParforProgMon/'); 
    pctRunOnAll javaaddpath(cd)
    cd(currdir)
    
    try  jm = findResource('scheduler', 'configuration', defaultParallelConfig);
    catch me
        parallel = 0;
    end
    
end

disp('calling pRF_estimate function...')
if strcmp(opt.gof,'mse')
    output_filename = 'myprfs_mse.mat';
else
    output_filename = 'myprfs_corr.mat';
end
[pRFs HDR opt pRFs_ihdr misc] = pRF_Estimate(vtc,stim,s,lrs,opt);
save(output_filename, 'pRFs', 'HDR', 'opt', 'pRFs_ihdr', 'misc', 'knownPRFs', 'rndmnoise', 'vtc');
%% show the results

disp('   center_x  center_y   sigma1      sigma2    amp1       amp2  correlation  ')
fprintf('\n')
known = ([cat(1,knownPRFs(:).center) cat(1,knownPRFs(:).sig) cat(1,knownPRFs(:).amp) cat(1,knownPRFs(:).offset)]); open known
est = ([cat(1,pRFs(:).center) cat(1,pRFs(:).sig) cat(1,pRFs(:).amp) cat(1,pRFs(:).offset) cat(1,pRFs(:).co)]); open est
%% plot
% find unstimulated area:
figure(100);
[~,ind] = min(abs(s.x(1,:)));
% plot(s.y(s.y(:,1)>0,1),mean(s.frames(s.y(:,1)>0,ind,:),3),'.-')
bla = find(mean(s.frames(s.y(:,1)>0,ind,:),3)>0,1,'first');
halfy = s.y(s.y(:,1)>0,1);
unstimulated_center = halfy(bla);
unstimulated_center = 0;


k_center = cat(1,knownPRFs(:).center);
[k_polang k_ecc] = cart2pol(k_center(:,1),k_center(:,2));
% eliminate knownpRFs whose centers are in the unstimulated area
k_polang(k_ecc<unstimulated_center)=NaN;
k_ecc(k_ecc<unstimulated_center)=NaN;

e_center = cat(1,pRFs(:).center);
[e_polang e_ecc] = cart2pol(e_center(:,1),e_center(:,2));


figure(2); clf; set(gcf,'position',[360,3,427,914;])

subplot(3,1,1); hold on
title(['noise in simulated fMRI: ' num2str(rndmnoise)])
plot(k_ecc,e_ecc,'.b')
ylabel('estimated eccentricity')
xlabel('real eccentricity')
xlims = get(gca,'xlim');
ylim(xlims)
a = axis;
plot(a(1:2),a(1:2))
xlim(xlims)
ylim(xlims)
axis square
axis square

subplot(3,1,2); hold on
plot(k_polang,e_polang,'.g')
ylabel('estimated polar angle')
xlabel('real polar angle')
xlims = get(gca,'xlim');
ylim(xlims)
a = axis;
plot(a(1:2),a(1:2))
xlim(xlims)
ylim(xlims)
axis square
axis square

subplot(3,1,3); hold on
h = plot(cat(1,knownPRFs(:).sig),cat(1,pRFs(:).sig),'.');
set(h(2),'color','r')
ylabel('estimated sigma')
xlabel('real sigma'); 
xlims = get(gca,'xlim');
ylim(xlims)
a = axis;
plot(a(1:2),a(1:2))
xlim(xlims)
ylim(xlims)
axis square
% break
% also look at
if opt.estimatehdr
    fprintf('\n\n')
    disp('pRFs_ihdr: tau delay voxelno ')
    disp([cat(1,pRFs_ihdr(:).tau) cat(1,pRFs_ihdr(:).delay) cat(1,pRFs_ihdr(:).id)])
end
%% amp and offset
figure(1001); clf;set(gcf,'position',[360,3,427,914;])

subplot(2,1,1); hold on
h = plot(cat(1,knownPRFs.amp),cat(1,pRFs.amp),'.'); set(h(2),'color','r');
h = plot(cat(1,knownPRFs.amp),cat(1,knownPRFs.amp),'-'); set(h(2),'color','r');
axis square
ylabel('amplitude')
subplot(2,1,2); hold on
plot(cat(1,knownPRFs.offset),cat(1,pRFs.offset),'.'); 
h = plot(cat(1,knownPRFs.offset),cat(1,knownPRFs.offset),'-'); 
axis square
ylabel('offset')
return
%% pred and observed
s = s; figure(1000); clf; clear err co
for vx = 1:length(pRFs)
   subplot(4,round(length(pRFs)/4),vx); 
hold on
   plot(vtc(vx).tc,'b-')
   RF = pRFs(vx); 
%    RF.offset
%    RF.amp(2) = .2;
   PredResp = 0;
   for ind = 1:1+strcmp(opt.prfmodel,'DoG')
       PredResp = PredResp + sign((ind<2)-.5) * RF.amp(ind) * UnwrappedConvStim*Gauss(RF,s.x,s.y,ind,1);
   end
   PredResp = RF.offset + PredResp;
   plot(PredResp,'r-')
   err(vx,1) = mean( (vtc(vx).tc-PredResp).^2 );
   tmp = corrcoef(vtc(vx).tc,PredResp);
   co(vx,1) = -tmp(1,2);
end
[cat(1,pRFs.err) err]
[err co]
figure(12);clf
plot(co,err,'.')

figure(88); clf
plot(known(:,5),est(:,3),'.')
xlabel('known amplitude')
ylabel('estimated sigma')

