% pRF_Mapping.m
% run to map pRF
%
% adapted from ScotomaStimulus.m by ZRE 10.20.2011
% scanned ZRE (03.06.2012)
%   - 10 runs (1:4&10 right hand responses, 5:9 left hand responses)

% 03.15.2012 PB extensive changes to add MultiFocal stimuli
%   THEORY
%   - MultiFocal stimuli (Vanni et al., NeuroImage 2006; current
%   parameters courtesy of Omar Butt in Aguirre/Brainard lab). 48 arcs 
%   (6 rings, 8 wedges), a variable combination of which is presented every
%   second frame (TR). TR must be set to 3. Stimulus sequence is defined by
%   a file OB sent to GMB; it was originally created with m-sequences.
%   Ring eccentricities were modified to cover a smaller area.
%   IsoAreaArcs_createMFstimulus.m makes the necessary files and
%   illustrates the reasoning. 
%   IMPLEMENTATION
%   - a flickering checkerboard (created with makeBarImage) covers the
%   whole screen tarea except the blanks defined by makeMaskImage &
%   makeScotomaImage. Within the stimulus aperture, 'non-stimulated areas'
%   (in a given TR) are covered with grey arcs (FrameArc ptb function) so
%   that the flickering checkerboard is visible only in 'stimulated areas'.
%   White lines mark the edge of each ring (necessary to hide somett
%   fuzziness in FrameArcttr that occasionally leads to skipping 1-2 px
%   between adjacent rings)
% 06.04.2012 PB added blank periods in the drifing bar sequence (duration: stim.durBlanksSec)
% 06.04.2012 PB changed bar width to stimulusradius/4 (as in Dumoulin)


%PsychJavaTrouble
clear all
clear mex
KbName('UnifyKeyNames') 
commandwindow
%% lets begin
% save the variables even if the script didn't run until the end
always_save = 1;

% stimulus type
stim.StimulusType = 'DriftingBar'; %'MultiFocal'; % 'RandomBar'; %
% chose task
task.type =  'simon'; %'letter'; % 'contrast'; %

% directory structure:
subj = 'tmp'; % if *test* only 2 TRs

% set directories and screen size
homedir = cd; %
display.gammaFileNm = 'luminanceGammaPowerFit_UWscanner.mat'; % this file must be in the path
display.dist = 68; % distance from screen (cm)
display.width = 33; % width of screen (cm)
display.debug_small = 1; % for debug purpose, creates a small ptb window

% to rescale all stimuli 
stim.correctionFactor = 1; 

datadir = fullfile( homedir, 'data', subj );
if ~exist(datadir,'dir')
    mkdir(datadir)
end
fileName = sprintf( 'Stimulus_%s_%s_%s', stim.StimulusType, subj, datestr( now, 'YYYY_mm_dd_HH_MM_SS' ) );

% deal with mac keyboard 
a = cd;
if a(1)=='/' % mac or linux
    a = PsychHID('Devices');
    for i = 1:length(a), d(i) = strcmp(a(i).usageName, 'Keyboard'); end
    keybs = find(d);
else % windows
    keybs = 1;
end

% Load luminance gamma table for the scanner:
if exist(display.gammaFileNm,'file')
    load( display.gammaFileNm, 'Linv' );
    display.gamma = Linv(:,4)-1; % pull out achromatic
else
    display.gamma = 0:255;
    fprintf( 'Warning! calibration file: %s\n not found\nusing linear look-up table instead\n', display.gammaFileNm )
end
Linearize = @(RGB) display.gamma( RGB+1 ); % pass values through gamma lookup table
rescale2RGB = @(img, pContrast) round( ( pContrast*img + 1)*127.5 ); % rescale img (-1 to 1) to RGB (0 to 255)

% load MultiFocal stimulus definition file 
if strcmp(stim.StimulusType,'MultiFocal')
    stim.correctionFactor = scaling_for_scotomaexp( display ) ;
    load MFStimLayoutAndSequence.mat
    if ~isempty(strfind(subj,'test'))
        stimSeq = stimSeq(:,1:2);
    end
    % check that scaling factor used in stimulus definition is the same
    % as here
    if abs( correctionFactor - stim.correctionFactor ) > ( 10^-10 ) % if the difference is not VERY small
        error(' display settings incompatible with stimulus layout ' )
        return
    end
end

%% parameters

% disp parameters:
display.screenNum = max(Screen('Screens'));
display.skipChecks = 2;
display.fixColor = [0 0 255]; % fixation only employed in contrast task
display.bkColor_PreGamma = [128 128 128];


switch stim.StimulusType
    case 'RandomBar'
        
        % bar parameters:
        stim.radDeg = 8; % circular aperature
        stim.widthDeg = 2; % bar width
        stim.cyclePerDeg = .5; % checkerboard
        stim.flickerHz = 8;
        
        % sequence params
        stim.durSec = 80; %
        if ~isempty(strfind(subj,'test'))
            stim.durSec = 2;
        end
        stim.secPerTR = 1;
        stim.numTRs = stim.durSec / stim.secPerTR;
        stim.nSteps = (stim.radDeg*2);
        stim.degPerSecRange = [ NaN NaN ]; % redefined based on stim.nSteps

        
        % other params
        stim.fixMaskRadDeg = 0; % mask around fixation
        % scotoma
%         if ~strcmp(subj,'test')
%             stim.scotoma.flag = (menu('Scotoma?','Yes','No') == 1);
%         else
            stim.scotoma.flag = 0;
%         end
        stim.scotoma.rad = [1 1] * 2;
        stim.scotoma.center = [2 2];

        stim.durBlanksSec = 30; % durantion of blanks between bar sweeps
        stim.nSweepsBetweenBlanks = 3*1; % number of sweeps separating two blank periods
        %
        stim.seed = 8194; % best seed out of 1:1e5
        rand('seed',stim.seed); % set seed
        
    case 'MultiFocal'
        
        % arcs parameters
        stim.wedgeStartDeg = regDef(:,1);
        stim.wedgeSizeDeg = regDef(:,2);
        stim.ringOutDeg = regDef(:,3) + regDef(:,4); % radius of the outer circle where the arc is inscribed
        stim.ringSizeDeg = regDef(:,4); % arc width
        
        % stimulus aperture
        stim.radDeg = max( stim.ringOutDeg ); % (outer bound of) outermost of stimulated arcs
        
        % mask around fixation
        stim.fixMaskRadDeg = min( stim.ringOutDeg - stim.ringSizeDeg ); % (inner bound of) innermost of stimulated arcs
        
        % add one more arc to delimit the fixation mask
        stim.wedgeStartDeg = [ stim.wedgeStartDeg ; 0 ] ;
        stim.wedgeSizeDeg = [ stim.wedgeSizeDeg ; 360 ] ;
        stim.ringOutDeg = [ stim.ringOutDeg ; regDef(1,3) ] ;
        stim.ringSizeDeg = [ stim.ringSizeDeg ; regDef(1,4) ] ;
        
        % bar parameters:
        stim.widthDeg = 100; % bar width -> must cover whole screen 
        stim.cyclePerDeg = .5 / stim.correctionFactor; % checkerboard
        stim.degPerSecRange = [ 0 0 ] ; % range of speeds
        stim.flickerHz = 8;
        stim.durBlanksSec = 0; % durantion of blanks between bar sweeps: not used here
        stim.nSweepsBetweenBlanks = Inf; % number of sweeps separating two blank periods: not used here
        
        % scotoma
        if ~strcmp(subj,'test')
            stim.scotoma.flag = (menu('Scotoma?','Yes','No') == 1);
        else
            stim.scotoma.flag = 0;
        end
        stim.scotoma.rad = [1 1] * 3 * stim.correctionFactor;
        stim.scotoma.center = [0 0];
        
        % sequence params
        stim.activeRegions = stimSeq; % pre-set stimulus sequence
        stim.secPerTR = 3;
        stim.numTRs = size( stim.activeRegions,2 ) ;
        stim.durSec = stim.numTRs * stim.secPerTR ; 


    case 'DriftingBar'
        
        % bar parameters:
        
        % always set max radius to max dim
        res = Screen('resolution',display.screenNum); 
        d = display; d.resolution = [res.width res.height];
%         stim.radDeg = pix2angle(d,min(d.resolution))/2;        
        stim.radDeg = 8; % circular aperature


        stim.widthDeg = stim.radDeg/4; %5; % bar width
        stim.cyclePerDeg = .5; % checkerboard
        stim.degPerSecRange = [ 1.25 1.75 ]; % range of speeds
        stim.flickerHz = 8;
        
        % sequence params
        stim.durSec = 240; %
        if ~isempty(strfind(subj,'test'))
            stim.durSec = 2;
        end
        stim.secPerTR = 1;
        stim.numTRs = stim.durSec / stim.secPerTR;
        
        % other params
        stim.fixMaskRadDeg = .9380; %as for multifocal.5; % mask around fixation
        % scotoma
        if ~strcmp(subj,'test')
            stim.scotoma.flag = (menu('Scotoma?','Yes','No') == 1);
        else
            stim.scotoma.flag = 0;
        end
        stim.scotoma.rad = [1 1] * 3 * stim.correctionFactor;
        stim.scotoma.center = [0 0];

        stim.durBlanksSec = 12*1; % durantion of blanks between bar sweeps
        stim.nSweepsBetweenBlanks = 3*1; % number of sweeps separating two blank periods
        %
        stim.seed = 8194; % best seed out of 1:1e5
        rand('seed',stim.seed); % set seed
        

    otherwise
        error('unknown stim.StimulusType')
end



% task params
if ~strcmp( task.type, 'simon' )
    % common task params
    task.pEvntPerSec = 1/4; % probability of event
    task.durSec = 12*1/60; % 6*1/60 = 100ms
    task.refractorySec = 1; % prevent tasks from occuring back-to-back (time following task offset)
    task.respWindSec = 1; % response window from task onset
    if strcmp( task.type, 'contrast' )
        task.contrast = .9; % percent contrast decrement
    elseif strcmp( task.type, 'letter' )
        task.target = '*';  % target letter
        display.text.font = 'futura';
        display.text.style = 0; % bold
        task.display.text.size = [ 8 60 ]; % range of target letter size as a funciton of eccentricity
        task.exponent = 2; % exponent of growth between above range
    end
end

%% try loop
try
    %% -- open window
    
    display.bkColor = Linearize( display.bkColor_PreGamma );
    display = OpenWindow(display);
    Screen( 'BlendFunction', display.windowPtr, 'GL_SRC_ALPHA', 'GL_ONE_MINUS_SRC_ALPHA' );
    % ListenChar(2);
    %
    stim.nFrames = ceil( stim.durSec * display.frameRate );
    rect = Screen('Rect', display.windowPtr );
    centerRect =  repmat( display.center, 1, 2);
    display.screenAngle = pix2angle( display, display.resolution );
    if any( 2*stim.radDeg > display.screenAngle )
        error( 'resize stimulus -- you are outside the bounds of your monitor' )
        Screen('CloseAll'); % ListenChar(1);
    end
    %     Screen('CloseAll'); ListenChar(1); disp('You are in debug mode'); return % debug-mode
    
    %% -- generate stimulus sequence


    switch stim.StimulusType
        case 'RandomBar'
            stim = getRandomBarSequence( stim );
        case 'DriftingBar'
            stim = getBarSequence( stim );
        case 'MultiFocal'
            stim = getBarSequence( stim );
            
            % modify a bar parameters and do deg2pix conversions
            % keep the bar fixed in the same pos and orient
            stim.motDirsRad = stim.motDirsRad*0;
            stim.centersDeg = stim.centersDeg*0;
            
            % define the rectangles where each arc is inscribed & and its
            % width
            ArcsRectPix = angle2pix( display, [ -repmat(stim.ringOutDeg,1,2)  +repmat(stim.ringOutDeg,1,2) ] ) + ...
                + repmat( display.center,size(stim.ringOutDeg,1),2 ) ; % [left, top, right, bottom]
            ArcsPenWidthPix = angle2pix( display,stim.ringSizeDeg );
    end
    
    
    Mask = makeMaskImage( display, stim );
    StimMask = abs(makeBarImage( display, stim ));

    if stim.scotoma.flag 
        scotomaImg = makeScotomaImage( display, stim );
        Mask = ~Mask; % 0 = non stimulated (i.e. Masked)
        Mask = Mask .* scotomaImg; 
        Mask = ~Mask; % switch back -> 1 = non stimulated (i.e. Masked)
    end
    
    % make textures
    stim_tmp = stim; stim_tmp.widthDeg = stim.radDeg*4; 
    ndrfitpos = 10;
    for ph = 1:ndrfitpos
        
        carrier = makeBarImage( display, stim_tmp, 0, [-ph/(ndrfitpos*stim.cyclePerDeg) 0] );
        thisign = sign((~mod(ph,2))-0.5);
        img1 = rescale2RGB( -carrier, 1 ); % rescale img to RGB vals (100% contrast)
        img2 = rescale2RGB( carrier, 1 ); % phase-reversed
        Texture(1,ph) = Screen('MakeTexture', display.windowPtr, Linearize( img1 ) );
        Texture(2,ph) = Screen('MakeTexture', display.windowPtr, Linearize( img2 ) );
    end
    clear stim_tmp;
    %
    maskImg = repmat( 128*ones( size(Mask) ), [1 1 4] );
    maskImg(:,:,4) = 255*double(Mask); %alpha-channel - invert to make 1's into 0's (0=100% opaque)
    TextureMask = Screen('MakeTexture', display.windowPtr, Linearize( maskImg ) );
    
    stimImg = repmat( 128*ones( size(StimMask) ), [1 1 4] );
    stimImg(:,:,4) = 255*double(~StimMask); %alpha-channel - invert to make 1's into 0's (0=100% opaque)
    TextureStimMask = Screen('MakeTexture', display.windowPtr, Linearize( stimImg ) );

    % reformat stim.centersDeg in rect space
    stimCentersPix = angle2pix( display, stim.centersDeg );
    destRect = repmat( rect, stim.numTRs, 1 ) + [stimCentersPix stimCentersPix ] ;
%     % compute horizontal and vertical tail of the dest rect
%     Hdispl = destRect(:,1)+rect(3); Hdispl = Hdispl.*double(Hdispl<rect(3));
%     Vdispl = destRect(:,2)+rect(4); Vdispl = Vdispl.*double(Vdispl<rect(4));
%     HtailRect = [Hdispl    Vdispl*0 rect(3).*double(Hdispl>0)+Hdispl Hdispl*0+rect(4)];
%     VtailRect = [Hdispl*0  Vdispl   Hdispl*0+rect(3) rect(4).*double(Vdispl>0)+Vdispl];    
%     
%     % when the stim rect moves, put a blank screen at its tail 
%     % [coord(xstart,ystart,xend,yend) tails(left,right,up,down) TRs]
%     Tail = NaN(size(destRect,2),4,size(destRect,1));
%     for i = 1:size(destRect,1)
%         Tail(:,1,i) = [0 0 max(0,destRect(i,1)) rect(4)]';
%         Tail(:,2,i) = [min(rect(3),rect(3)+destRect(i,1)) 0 rect(3) rect(4)]';
%         Tail(:,3,i) = [0 0 rect(3) max(0,destRect(i,2))]';
%         Tail(:,4,i) = [0 min(rect(4),rect(4)+destRect(i,2)) rect(3) rect(4)]';
%     end
    
    % deal with task
    rand( 'seed', GetSecs ); % randomize seed for task
    if strcmp( task.type, 'simon' )
        % set up Simon
        task = doSimon(display);
        task.type = 'simon'; % task gets cleared inside of simon
        task.ISI = 1/3;  %seconds
        task.dur = .25;   %seconds
        task.pauseDur = .25; %seconds
        task.errDur = 1;  %seconds
        task.errFreq = 4;  %Hz
        task.keys = {'b','y','g','r'};%{'w','s','a','q'};
    else
        % response params
        task.pEvntPerFrame = task.pEvntPerSec / display.frameRate;
        respCnt = 0;
        evntCnt = 0;
        task.respSec = [];
        task.eventSec = [];
        task.eventHit = []; % 1=hit; 0=miss
        task.respHit = []; % 1=hit; 0=FA
        eventUntilSec = 0;
        lookForResp = false;
        drawFix( display );
        if strcmp( task.type, 'contrast' )
            % make other two textures
            img3 = rescale2RGB( carrier, task.contrast );
            img4 = rescale2RGB( -carrier, task.contrast ); % phase-reversed
            Texture(3) = Screen('MakeTexture', display.windowPtr, Linearize( img3 ) );
            Texture(4) = Screen('MakeTexture', display.windowPtr, Linearize( img4 ) );
        elseif strcmp( task.type, 'letter' )
            task.letterLoc = [];
        end
    end
    
    % wait for ttl-pulse
    drawText( display, [0 1], '*waiting for ttl-pulse*' );
    Screen('Flip',display.windowPtr);
    wait4T(keybs);  %wait for 't' from scanner.
    
    %% -- play movie
    
    breakIt = 0;
    frameCnt = 1;
    timeStamp = 0;
    display.timeStamp = zeros( 1, stim.nFrames );
    startTime = GetSecs;  %read the clock
    while GetSecs-startTime < stim.durSec && ~breakIt  %loop until 'esc' pressed or time runs out
        elapsedTime = GetSecs-startTime;   %calculate the current time elapsed
        curTR = ceil( elapsedTime / stim.secPerTR );
%         flickState =  ceil( mod( elapsedTime * stim.flickerHz, 1) +.5 );
        flickState =  round( mod( elapsedTime * stim.flickerHz, 1) ) +1;
%         driftState =  round( mod( elapsedTime * stim.flickerHz/2, 1) ) +1;
driftState =  ceil( mod( elapsedTime * stim.flickerHz, ndrfitpos) );
        % check for an event
        contrastDec = 0;
        letterOn = false;
        if ~strcmp( task.type, 'simon' )
            % check for an event (if not currently in an event or refractory state & not too close to edge)
            if rand(1) <= task.pEvntPerFrame &&...
                    elapsedTime > eventUntilSec + task.refractorySec &&...
                    sqrt( sum( stim.centersDeg(curTR,:).^2) ) < floor( stim.radDeg )
                evntCnt = evntCnt + 1;
                task.eventSec( evntCnt ) = elapsedTime;
                task.eventHit(evntCnt) = 0; % miss unless response determines otherwise
                eventUntilSec = elapsedTime + task.durSec; % event occurs for some number of TRs
                lookForResp = true;
                timeStamp = elapsedTime;
                % determine letter properties
                randNum = 2*rand(1)-1;
                curCenter = stim.centersDeg(curTR,:);
                scaleFactor = ( ( stim.radDeg - sqrt(sum(curCenter.^2))) / stim.radDeg );
                r = randNum * (scaleFactor*stim.radDeg); % long axis
                theta = stim.motDirsRad( curTR )+pi/2;
                xyLetterLoc(1) = r * cos( theta );
                xyLetterLoc(2) = r * sin( theta );
                task.letterLoc( evntCnt, : ) = xyLetterLoc + [curCenter(1) -curCenter(2)]; % save it
            end
            % task on!
            if elapsedTime <= eventUntilSec
                if strcmp( task.type, 'contrast' )
                    contrastDec = 1;
                elseif strcmp( task.type, 'letter' )
                    letterOn = true;
                    % update letter location
                    curCenter = stim.centersDeg(curTR,:);
                    letterLoc = xyLetterLoc + [ curCenter(1) -curCenter(2) ]; % shift it (negative y for drawText)
                    % adjust letter size
                    a = ( sqrt( sum( letterLoc.^2 ) ) / floor( stim.radDeg ) )^task.exponent;
                    display.text.size = round( task.display.text.size(1) + a*diff(task.display.text.size) );
                    % turn-off if out-of-bounds
                    if sqrt( sum( letterLoc.^2 ) ) > stim.radDeg;
                        letterOn = false;
                    end
                end
            end
        end
        
        % draw stim and mask
        % notes on DrawTexture:
        % first: DrawTexture rotates clockwise instead of
        % counter-clockwise (like I assume in radians) so I subtract
        % the direction from 2*pi first and everything is good
        % second: rotation is in deg instead of radians
        
        
        if strcmp(stim.StimulusType,'MultiFocal')
            barAngDeg = mod( elapsedTime*360/10, 360 );
            driftState = 1;
        else
            barAngDeg = (2*pi-stim.motDirsRad(curTR)) * 180/pi;
        end
        % carrier texture
        Screen( 'DrawTexture', display.windowPtr, Texture(flickState+2*contrastDec,driftState), [], destRect(curTR,:), barAngDeg ); %
        % bar aperture
        Screen( 'DrawTexture', display.windowPtr, TextureStimMask , [], destRect(curTR,:), barAngDeg )
        % circular aperture
        Screen( 'DrawTexture', display.windowPtr, TextureMask )
        if letterOn
            drawText( display, letterLoc, task.target, display.bkColor );
        end
        
        % if Multifocal stimuli, draw arcs in all 'inactive' stimulus
        % regions => the underlying flickering checkerboard remains visible only in 'active' regions 
        if strcmp(stim.StimulusType,'MultiFocal')
            
            InActiveRegs = find( stim.activeRegions(:,curTR) == 0 ); % find inactive regions
            for ct = 1:length(InActiveRegs)
                i = InActiveRegs(ct);
                Screen('FrameArc',display.windowPtr,display.bkColor,ArcsRectPix(i,:) ,stim.wedgeStartDeg(i,:),...
                    stim.wedgeSizeDeg(i,:),ArcsPenWidthPix(i,:)); 
            end
            
            % add white lines to separate rings
            [bla,ind] = unique( stim.ringOutDeg );
            for ct = 1:length( ind)
                i = ind(ct);
                Screen('FrameArc',display.windowPtr, [1 1 1]*255, ArcsRectPix(i,:)+[-1 -1 +1 +1]*1, 0, 360, 2); % 2px width
            end
                
        end
        
        % deal with task and user response
        if strcmp( task.type, 'simon' )
            task = doSimon(display, task, elapsedTime,keybs);
        else
            drawFix( display );
            if CharAvail
                ch = GetChar;
                if strcmp(ch, 'r')
                    respCnt = respCnt+1;
                    task.respSec( respCnt ) = elapsedTime;
                    if lookForResp
                        % HIT
                        task.eventHit(evntCnt) = 1;
                        task.respHit(respCnt) = 1;
                        lookForResp = false;
                    else
                        % FALSE ALARM
                        beep
                        task.respHit(respCnt) = 0; % FA
                    end
                end
            end
            % look for miss!
            if lookForResp && elapsedTime > eventUntilSec - task.durSec + task.respWindSec
                % MISS
                beep
                lookForResp = false;
            end
        end
        Screen('Flip', display.windowPtr);
        display.timeStamp(frameCnt) = GetSecs-startTime;
        
        % check to see if the "esc" button was pressed
        breakIt = escPressed(keybs);
        frameCnt = frameCnt + 1;
    end
    frameCnt = frameCnt-1;
    % crop end off of timeStamp in case frames were dropped
    display.timeStamp = display.timeStamp( 1:frameCnt );
    fprintf( 'Elapsed time %.0f sec (expected: %.0f)\n', display.timeStamp(end), stim.durSec )
    fprintf( '# of frames displayed - expected = %.0f\n', frameCnt-stim.nFrames )
    
    % clean up the Simon process
    if strcmp( task.type, 'simon' )
        task.action = 'done';
        task = doSimon(display, task, elapsedTime,keybs);
        Screen('Flip', display.windowPtr);
    end
catch ME
    Screen('CloseAll');
    % ListenChar(0);
    rethrow(ME);
end
Screen('CloseAll');
% ListenChar(0);

%% save data

if ~breakIt  || always_save
    save( fullfile( datadir, fileName ), 'display', 'stim', 'task');
    fprintf( 'DATA SAVED:\n\t%s\n\t%s\n', datadir, fileName )
end


%% plot results

if isfield(task,'eventHit')
    fprintf( '\nhit rate = %.2f\n', mean(task.eventHit) ); 
    fprintf( 'false-alarm rate = %.2f\n', mean(~task.respHit) );
end
if ~exist( 'breakIt', 'var' ); breakIt = false; end
if ~breakIt
    figure(1); clf
    set(gcf,'position', [ 1 31 1024 664]);
    switch task.type
        case 'simon'
%             plotSimon(task);
            s = task;
            plotSimon;
        case 'letter'
            subplot 211
            stem( task.respSec(task.respHit), ones( 1, sum(task.respHit)), 'g', 'MarkerFaceColor', 'g' ); hold on
            stem( task.respSec(~task.respHit), ones( 1, sum(~task.respHit)), 'y', 'MarkerFaceColor', 'y' );
            stem( task.eventSec(~task.eventHit), ones( 1, sum(~task.eventHit)), 'r', 'MarkerFaceColor', 'r' );
            % legend -- plot off screen in case there are no misses or false-alarms!
            col = 'gyr';
            for i=1:3; h(i)=plot( -1,0,'ko','MarkerFaceColor',col(i)); end
            hL = legend( h, 'hits', 'misses', 'false-alarms', 'Location', 'SE' );
            set( hL, 'color', .5*ones(1,3) )
            % labeling
            xlabel( 'time (sec)' ); xl(0, stim.durSec); yl(0, 1.2)
            set( gca, 'YTick', [], 'XTick', 0:40:stim.durSec, 'color', [0 0 0] )
            title( sprintf( 'responses over time\n(hit rate = %.0f%% -- false-alarm rate = %.0f%%)', 100*mean(task.eventHit), 100*mean(~task.respHit) ) )
            
            subplot 212
            plot( [0 stim.radDeg+1], mean(task.eventHit)*[1 1], 'k:' ); hold on
            %
            letterDist = sqrt( sum( task.letterLoc.^2, 2 ) );
            N = hist( letterDist, binCenters );
            binWidth = mean( diff(binCenters) );
            %
            patch( [0 stim.radDeg+1 stim.radDeg+1 0 ], [1 1 1.1 1.1 ], .8*ones(1,3) )
            text( .3, 1.04, 'N =' )
            for i = 1:length(binCenters)
                id = letterDist > binCenters(i)-binWidth/2 & letterDist < binCenters(i)+binWidth/2;
                pC(i) = mean( task.eventHit( id ) );
                plot( binCenters(i), pC(i), 'o', 'MarkerFaceColor', 'b', 'MarkerSize', 30*N(i)/max(N) )
                %
                text( binCenters(i), 1.05, num2str(N(i)), 'HorizontalAlignment', 'center' )
            end
            text( binCenters(end)+.9, 1.05, sprintf( '= %g ', sum(N) ), 'HorizontalAlignment', 'right' )
            plot( binCenters, pC, '-' )
            %
            xlabel( 'distance from fixation (deg)' )
            ylabel( 'hit rate' ); yl( 0,1.1 )
            set( gca, 'TickDir', 'out' )
            title( 'performance as a function of eccentricity' )
    end
end

%% plot timing

plotIt = false; % true; %
if ~breakIt && plotIt
    figure(2); clf
    plot( diff( display.timeStamp ), '.-' ); hold on
    set( gca, 'YTick', 0:1/stim.flickerHz:1 ); grid on
    title( 'flip-to-flip time' )
    ylabel( 'time elapsed since previous frame (ms)' ); xlabel( 'frame' )
    yl( 0, max( [1/stim.flickerHz myylim(2)] ) )
end

return

