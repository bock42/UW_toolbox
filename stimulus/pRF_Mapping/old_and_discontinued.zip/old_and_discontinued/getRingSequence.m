function stim = getRingSequence( stim )
% stim = getRingSequence( stim );
%
% DESCRIPTION
% Computes center of the ring stimulus. 
% INPUT
%   stim
%       .numTRs     - duration of sequence in TRs
%       .degPerSec  - a min and max speed in deg/sec
%   	.radDeg     - radius of apperture in degrees
%   	.widthDeg   - width of bar in degrees
% OUTPUT
%   stim
%       .centersDeg - centers in deg, (0,0) is screen center (-y is up)
%   	.motDirsRad     - direction of motion in radians (0 to the right, pi/2 is up)
%   	.degPerSec  - instantaneous speed at every TR

% VERSION HISTORY
%   1.0 (10.27.2011, ZRE)
%       - created
%   1.1 (02.22.2012, ZRE)
%       - the seed for rand() is now set here
%       - changed stim.ang -> stim.angsRad 
%       - revised comments
%   1.2 (02.24.2012, ZRE)
%       - change stim.angsRad -> stim.motDirsRad

%   0604.2012, PB
%       - allows bar to drift out of the screen (introducing blank periods)

% if isfield( stim, 'seed' )
%     % set seed to generate standard sequence
%     rand('seed',stim.seed); 
% end

% [curCenter, theta, degPerSec, dx, dy] = getNewBar( stim ); 
stim.centersDeg = zeros(stim.numTRs,2);
% stim.motDirsRad = zeros(stim.numTRs,1);
% move stimulus every TR

% nBlankFrames = round(stim.durBlanksSec/stim.secPerTR);
% blankFr = 0;
% nSweeps = 0;

radii = 1:2:10;
R = [];
for iTR = 1:4:stim.numTRs
    
    
    radius = radii(1+mod(ceil((iTR-4)/length(radii)),length(radii))); R = [R;radius];
    
end
R = Shuffle(R);
R = repmat(R,1,4)';
stim.centersDeg(:,1) = R(:);
% figure(1)
% 
% plot(R)
    
%     curCenter = curCenter + [dx,dy];
%     
%     if norm(curCenter) > stim.radDeg + stim.widthDeg/2
%         % stimulus center has moved outside of range
%         nSweeps = nSweeps + 1; % advance sweeps counter
%         
%         if nSweeps >= stim.nSweepsBetweenBlanks % if enough sweeps have been completed
%             % start counting blank frames
%             blankFr = blankFr + 1; % advance blank frames counter
%             
%             if blankFr >= nBlankFrames % if enough blank frames have passed
%                 
%                 % generate a new bar
%                 [curCenter, theta, degPerSec, dx, dy ] = getNewBar( stim );
%                 
%                 blankFr = 0; % reset blank frames counter
%                 nSweeps = 0; % reset sweeps counter
%             end
%         else % if NOT enough sweeps have been completed, generate a new bar (skip the blank)
%             [curCenter, theta, degPerSec, dx, dy ] = getNewBar( stim );
%         end
%     end
%     
%     stim.centersDeg(iTR,:) = curCenter;
%     stim.motDirsRad(iTR) = theta;
%     stim.degPerSec(iTR) = degPerSec;
% end
% 
% % embedded function
% function [ curCenter, theta, degPerSec, dx, dy ] = getNewBar( stim )
% theta = rand(1) * 2*pi; % pick a random direction of motion
% 
% degPerSec = rand(1) * ( max(stim.degPerSecRange)-min(stim.degPerSecRange) ) + min(stim.degPerSecRange);
% curCenter = -(stim.radDeg+stim.widthDeg/2) * [cos(theta), -sin(theta)];
% dx = cos(theta) * degPerSec * stim.secPerTR;
% dy = -sin(theta) * degPerSec * stim.secPerTR;
