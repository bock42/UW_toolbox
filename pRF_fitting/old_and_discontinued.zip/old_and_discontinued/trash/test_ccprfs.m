cls

% source files
subjectdir = '';
% homedir = '/home/pbinda1/Andrew/data/con15/'; % Resting data
% vtcname = 'bold/001/rf.150.tf.nii'; % resting state
homedir = '/home/pbinda1/Andrew/data/Paola/con1/'; % Resting data
vtcname = 'bold/001/stim2rest.nii'; % stimulus

% where to save fit values
targetdir = [cd '/data/'];
output_filename = 'ccprfs_LR.mat';



%% load ROIs
hemi = {'lh','rh'};
V1name = '.V1.f.nii';
V2name = '.V2.f.nii';

V1mask = 0; V2mask = 0;
ecc = 0; pol = 0;
for hh = 1%1:length(hemi)
    
    pathtoV1 = [homedir subjectdir hemi{hh} V1name];
    tmp = load_untouch_nii(pathtoV1); V1mask = V1mask + tmp.img; % binary mask

    pathtoV2 = [homedir subjectdir hemi{hh} V2name];
    tmp = load_untouch_nii(pathtoV2); V2mask = V2mask + tmp.img; % binary mask
    
    tmp = [hemi{hh} '.V1.ecc.f.nii'];
    pathtotmp = [homedir subjectdir tmp];
    tmp = load_untouch_nii(pathtotmp); ecc = ecc + tmp.img; % values + zeros outsied roi
    
    tmp = [hemi{hh} '.V1.pol.f.nii'];
    pathtotmp = [homedir subjectdir tmp];
    tmp = load_untouch_nii(pathtotmp); pol = pol + tmp.img; % values + zeros outsied roi

end

V1mask = logical(V1mask);
V2mask = logical(V2mask);

V1.ecc = double(ecc(V1mask)) / 10;
V1.pol = double(pol(V1mask)) / 180 * pi ;

V1.id = find(V1mask);
V2.id = find(V2mask);
% hist(V1.pol,50)
% return
%% load fMRI data
% load whole brain, select V1 and V2 only
pathtovtc = [homedir subjectdir vtcname];

vtc = load_untouch_nii(pathtovtc);
vtc = shiftdim(vtc.img,3);
siz = size(vtc);
vtc = double(reshape(vtc, siz(1), siz(2)*siz(3)*siz(4)));

V1.tc = vtc(:,V1.id);
V2.tc = vtc(:,V2.id);

clear tmp V1mask V2mask vtc

%% transform variables and set options for pRF fitting


[V1.x V1.y] = pol2cart(V1.pol,V1.ecc);

s.frames = V1.tc;
s.x = V1.x;
s.y = V1.y;

for vX = 1:size(V2.tc,2)
    vtc(vX).tc = V2.tc(:,vX);
    vtc(vX).id = V2.id(vX);
end

% options
opt.ccprs = 1;
opt.vtcsize = siz;
opt.parallel = 1;
% opt.rate4seeds = 5;

% other necessary input
stim.secPerTR = 2; % doesn't do anything
lrs = [];


%% call pRF_estimate (and open parallel pool, if an option)
if opt.parallel
    if matlabpool('size') == 0 % checking to see if my pool is already open
        matlabpool open 6 % number of cores you have
    end
    currdir = cd('../Parallelization/ParforProgMon/'); 
    pctRunOnAll javaaddpath(cd)
    cd(currdir)
    
    try  jm = findResource('scheduler', 'configuration', defaultParallelConfig);
    catch me
        parallel = 0;
    end
    
end

disp('calling pRF_estimate function...')

[pRFs HDR opt pRFs_ihdr misc] = pRF_Estimate(vtc,stim,s,lrs,opt);
save([targetdir output_filename], 'pRFs', 'HDR', 'opt', 'pRFs_ihdr', 'misc', 'vtc');

return

%%
close all
[polang ecc] = cart2pol(cat(1,mypRF.x),cat(1,mypRF.y));
sig = cat(1,mypRF.sig);
err = cat(1,mypRF.cc);
center = [cat(1,mypRF.x),cat(1,mypRF.y)];
subplot(2,1,1); 
plot(ecc,sig,'.')
% xlim([0 60])
ylim([0 10])
subplot(2,1,2)
hist(sig,0:.5:11); xlim([0 10]); set(gca,'yscale','log')
%%



% opt.ccprfs = 1;
% 
% s.frames = V1 activity
% 
% s.x = all id in V1
cls

% % weird create x,y
% 
% [x2 y2] = meshgrid(linspace(-10,10,201)');
% 
% sam = ceil(rand(200,2) * numel(x2));
% 
% x = x2(sam(:,1));
% y = y2(sam(:,2));

% % create x,y from polar coordinates
% polang = linspace(-pi,pi,201);
% ecc = logspace(0,1,201);
% [x y] = pol2cart(polang,ecc);

% % shuffle x,y
% x = Shuffle(x);
% y = Shuffle(y);
% 
% % sort x,y
% [x Ix] = sort(x);
% [y Iy] = sort(y);


% usual x,y
x = linspace(-10,10,201);
y = x;

[x2 y2] = meshgrid(x,y);
RF.center = [5 5]; RF.sig = 2;
% ind = 1;
G = Gauss(RF,x2,y2,1);
G = Gauss(RF,x,y,1);

% plot
figure(1); clf

% subplot(2,2,1); hold on
title('x vs y')
% plot(x,y,'.')
% imagesc(x,y,x2)
axis equal
% 
% subplot(2,2,2); hold on
% title('y')
% plot(y,'-')
% imagesc(x,y,y2)
% axis off

% subplot(2,2,3); hold on
title('G')
imagesc(x,y,G)
axis square

% xlim([min(x) max(x)])
% ylim([min(y) max(y)])




