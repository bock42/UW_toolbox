% cls
% 
% %% load stimulus file
% homedir = '/home/pbinda1/AAA miei/PAOLA32/Esperimenti/___genprogs/pRFs/';
% targetdir = '/data/test/';
% d = dir([homedir targetdir '*.mat']); stimulus_file = [homedir targetdir d(end).name];
% load(stimulus_file)
% 
% %% make stimulus movie
% stim_max_diam_deg = 2*max(stim.radDeg);
% equiv_screen_width = stim_max_diam_deg / display.screenAngle(2) * display.screenAngle(1) ;
% display.screenAngle = [equiv_screen_width stim_max_diam_deg];
% display.width =  2 * display.dist * tan( pi * display.screenAngle(1) / (2*180) ) ;
% dwns = 10;
% nPix = round(display.resolution/dwns);
% s = makeStimulusMovie( display, stim, nPix );

%% define pRF

centermat = round(size(s.x)/2);

prf.center = [0 0];
prf.sig = [1 3];
prf.amp = [1 0.5];

g = DoG( prf, s.x, s.y);
% g = Gauss( prf, s.x, s.y,1);
% 
%% plot
figure(1); clf
subplot(1,2,1); 
imagesc(g); colorbar
axis equal tight
subplot(1,2,2); 
plot(g(centermat(1),:));