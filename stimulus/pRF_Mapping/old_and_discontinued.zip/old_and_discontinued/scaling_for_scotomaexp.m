function correctionFactor = scaling_for_scotomaexp( display ) 
% correction factor for Scotoma Experiment (Geoff/Ione/Jess/Paola)
% required input:
% display.dist
% display.width
% 
% the first experiment in this study was run with a script that did not
% appropriately scale stimulus dimensions with screen size
% 
% the script worked by assuming that the stimulus was displayed within a
% squared area of 16 (assumed to be the screen height) x2 = 32 deg side 
% 
% in fact, the square window subtending the stimulus was about half that
% size
% 
% because we are running on the same monitor, we can reset the actual
% dimensions of the stimulus window to the real height of the display
% 
% then, we compute a scaling factor to apply to all parameters to compute
% their correct value in deg
% 
% 2012/03/23, PB

if nargin<1
    disp( 'correctionFactor = scaling_for_scotomaexp( display )' )
    return
end

% compute the actual display size
display.resolution = [ 1024 768 ] ; % resolution of the screen at the DISC 3T scanner
display.screenAngle = pix2angle( display, display.resolution ) ;
actual_maxRad = display.screenAngle(2)/2;
assumed_maxRad = 16;  % ASSUMED height/2 of the monitor in degrees

correctionFactor = actual_maxRad / assumed_maxRad; 


% below is an excerpt from the ScotomaStimulus.m script showing the
% inappropriate scaling 

% % parameters setup
% stim.maxRad = 16;  %degrees
% stim.width = 5; %degrees
% stim.speed = [2,2.5];  %speed range degrees/sec
% stim.TR = 1;    %seconds
% stim.dur = 240;%240; %seconds
% stim.seed = 1;  %random generator seed
% stim.sf = .5;  %c/deg
% stim.Hz = 8;  %flicker rate
% isScotoma = menu('Scotoma?','Yes','No');
% if isScotoma == 1
%     stim.scotoma.center = [0,0]; %center of scotoma
%     stim.scotoma.rad = 3;  %radius of scotoma
% end
% 
% % example of stimulus creation (this is a blank screen, see
% % getBarMask.m for another example)
% n = display.resolution(2);
% [x,y] = meshgrid(linspace(-stim.maxRad,stim.maxRad,n));
% 
% % example of texture creation and display
% blankImg = 128*ones(size(x));
% blankTex =  makeTexture(display,blankImg);
% Screen('DrawTexture', display.windowPtr,blankTex );
