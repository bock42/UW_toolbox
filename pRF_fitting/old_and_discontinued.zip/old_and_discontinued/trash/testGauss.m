clear all

xydef = 2; % 1:how I was thinking; 2:right way to think

RF.center = [7 0]; RF.sig = 2;



%% method 1: x,y linspace
if xydef == 1
    x = linspace(-10,10,201);
    y = x;
    
elseif xydef == 2
    % create surface
    [x2 y2] = meshgrid(linspace(-10,10,201)');
    
    % sample some
    sam = ceil(rand(500,2) * numel(x2));
    x = x2(sam(:,1));
    y = y2(sam(:,2));
end

[x2 y2] = meshgrid(x,y);
G = Gauss(RF,x2,y2,1);
G = Gauss(RF,x,y,1);

G = G / max(G(:));

%% plot

if xydef == 1
    figure(1); clf; hold on
    title('x vs y')
    plot(x,y,'.')
    % imagesc(x,y,x2)
    axis equal

    figure(2); clf; hold on
    title('G')
    imagesc(x,y,G)
    axis square
    
elseif xydef == 2
    
    figure(1); clf; hold on
    title('x vs y')
    plot(x,y,'.')
    % imagesc(x,y,x2)
    axis equal
    
    figure(2); clf; hold on
    title('G')
    
    for i = 1:length(x)
        plot(x(i),y(i),'o','Color',[G(i) 0 0])
    end
    axis equal
    
end
tilefigs
