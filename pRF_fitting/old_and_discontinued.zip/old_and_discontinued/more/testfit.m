cls

RF.center = [0 0];
RF.sig = 1;
RF.amp = 1;
RF.offset = 0;

[x y] = meshgrid( -10:.1:10 ) ;

randnoise = .05;

[~,resp] = fit_this_gauss(RF,x,y);

N = 10;
for i = 1:N
    
    randnoise = rand*0.1;
    noise = randn(size(resp)) * randnoise;
    observed_resp = resp + noise;
    
    [RFhat1(i) err_corr(i,1)] = fit('fit_this_gauss',RF,{'center','sig'},x,y,observed_resp,'corr');
    [RFhat2(i) err_mse(i,1)] = fit('fit_this_gauss',RF,{'center','sig'},x,y,observed_resp,'mse');
    
    
end

%% plot results
figure(1); clf; hold on
plot(err_corr,err_mse,'.')

figure(2); clf; hold on
plot(cat(1,RFhat1(:).sig),cat(1,RFhat2(:).sig),'.')
plot(cat(1,RFhat1(:).sig),cat(1,RFhat1(:).sig),'-')
